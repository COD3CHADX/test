package com.chadx.sockshttp.view;

import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.appcompat.widget.Toolbar;
import com.chadx.sockshttp.MyApplication;
import com.chadx.sockshttp.R;
import com.chadx.sockshttp.util.ConfigImpl;

public class TunnelTypeActivity extends AppCompatActivity
{
	private ConfigImpl mConfig;
	private RadioGroup rgTunType;
	private RadioGroup rgConnection;
	private CheckBox ckCustomPayload;
	private RadioButton rbDirect;
	private Button btnSave;
	private Toolbar toolbar;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_vpnmod);
		new MyApplication().init(this);
		if (new MyApplication().isNightModeEnabled()) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
        } else {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
        }
		mConfig = new ConfigImpl();
		this.toolbar = (Toolbar) findViewById(R.id.toolbar);
		new MyApplication().init(this);
        setSupportActionBar(this.toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		rbDirect = (RadioButton) findViewById(R.id.rbDirect);
		ckCustomPayload = (CheckBox) findViewById(R.id.ckCustomPayload);
		ckCustomPayload.setChecked(mConfig.isUsePayload());
		rgTunType = (RadioGroup) findViewById(R.id.rgTunnelType);
		rgTunType.check(mConfig.getTunnelType());
		rgTunType.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener(){
				@Override
				public void onCheckedChanged(RadioGroup p1, int p2){
					if (p2 == R.id.rbOvpn) {
						rbDirect.setChecked(false);
						rbDirect.setEnabled(false);
					} else {
						rbDirect.setEnabled(true);
					}
				}
			});
		rgConnection = (RadioGroup) findViewById(R.id.rgConnection);
		rgConnection.check(mConfig.getConType());
		rgConnection.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
				@Override
				public void onCheckedChanged(RadioGroup p1, int p2) {
					if (p2 == R.id.rbSSL) {
						ckCustomPayload.setEnabled(false);
						ckCustomPayload.setChecked(false);
					} else {
						if (mConfig.isUsePayload()) {
							ckCustomPayload.setChecked(true);
						} else {
							ckCustomPayload.setChecked(false);
						}
						ckCustomPayload.setEnabled(true);
					}
				}
			});
		btnSave = (Button) findViewById(R.id.btnSaveTunnelType);
		btnSave.setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View p1) {
					if (!mConfig.isHaveConfig()) {
						mConfig.setTunnelType(rgTunType.getCheckedRadioButtonId());
						mConfig.setConType(rgConnection.getCheckedRadioButtonId());
						if (mConfig.getTunnelType() == R.id.rbOvpn) {
							if (mConfig.getConType() == R.id.rbProxy) {

							}
						}
						if (ckCustomPayload.isChecked()) {
							mConfig.isUsePayload(true);
						} else {
							mConfig.isUsePayload(false);
						}
						finish();
					} else {
						Toast.makeText(MyApplication.getAppContext(), "You cannot edit Tunnel Type on this Config",0).show();
					}
				}
			});
		if (mConfig.getTunnelType() == R.id.rbOvpn) {
			rbDirect.setEnabled(false);
		} else if (mConfig.getConType() == R.id.rbSSL) {
			ckCustomPayload.setEnabled(false);
		}
	}

}
