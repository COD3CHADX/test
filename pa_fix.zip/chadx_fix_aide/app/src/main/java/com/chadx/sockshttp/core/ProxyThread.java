package com.chadx.sockshttp.core;


import android.content.SharedPreferences;


import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.util.Locale;
import com.chadx.sockshttp.MyApplication;
import com.chadx.sockshttp.logger.Log;

public class ProxyThread extends Thread {
    Socket incoming;
    Socket outgoing;
    private boolean clientToServer;
    private SharedPreferences sp;

    public ProxyThread(Socket socket, Socket socket2, boolean z) {
        incoming = socket;
        outgoing = socket2;
        this.clientToServer = z;
        sp = MyApplication.getSharedPreferences();
    }

    public final void run() {
        boolean debug = sp.getBoolean("debug",false);

        try{
            byte[] buffer;
            if (clientToServer) {
                buffer = new byte[Integer.parseInt(sp.getString("buffer_send", "1024"))];
            } else {
                buffer = new byte[Integer.parseInt(sp.getString("buffer_receive", "4096"))];
            }
            InputStream FromClient = this.incoming.getInputStream();
            OutputStream ToClient = this.outgoing.getOutputStream();
            while (true) {
                int numberRead = FromClient.read(buffer);
                if (numberRead == -1) {
                    break;
                }
                String result = new String(buffer, 0, numberRead);
                if (this.clientToServer) {
                    ToClient.write(buffer, 0, numberRead);
                    ToClient.flush();
                } else {
                    String[] split = result.split("\r\n");
                    if (split[0].toLowerCase(Locale.getDefault()).startsWith("http")) {
                        result = split[0].substring(9, 12);
                        addLog(result.replace("200",
                                              "<b>Status: 200 (Connection established) Successful</b> - The action requested by the client was successful")
                               .replace("403","<b>Status: 400 (Bad Request) - The client seems not completely established</b>")
                               .replace("400","<b>Status: 400 (Bad Request) - The client seems not completely established</b>")
                               .replace("503","<b>Status: 503 (Service Unavailable)</b>")
                               .replace("100","<b>Status: 100 (Authentication Success)</b>")

                               .replace("500","<b>Status: 500 (Internal Server Error)</b>")
                               .replace("407","<b>Status: 407 (Proxy Authentication Required) - You need to use proxy authorization</b>")
                               .replace("405","<b>Status: 405 (Method Not Allowed) - Extra Info: Please check your Payload</b>")
                               .replace("502","<b>Status: 502 (Gateway Timeout)</b>")
                               .replace("301","<b>Status: 301 (Moved Permanently) - Redirect: The client must take additional action to complete the request</b>")
							   .replace("101", "<b>Status: 101 (Switching Protocol)</b>")
                               .replace("402","<b>Status: 402 (Not Authenticated) - Please check your proxy server</b>")
                               .replace("302","<b>Status: 302 (Moved Permanently) - Redirect: The client must take additional action to complete the request</b>"));        
						if (result.indexOf("200") >= 0) {
                            ToClient.write(buffer, 0, numberRead);                           
                            ToClient.flush();                      
                        } else if (true) {
                            if (split[0].split(" ")[0].equals("HTTP/1.1")) {
                                addLog("<b>Extra Info</b> Please make sure your payload is correct.");
                                addLog("Sending 200 HTTP status - HTTP/1.1 200 OK");
                                ToClient.write(new StringBuilder(String.valueOf(split[0].split(" ")[0])).append(" 200 OK\r\n\r\n").toString().getBytes());
                            } else {
                                try {
                                    ToClient.write(new StringBuilder(String.valueOf(split[0].split(" ")[0])).append(" 200 Connection established\r\n\r\n").toString().getBytes());
                                } catch (Exception e) {                             
                                    try {
                                        if (this.incoming != null) {
                                            this.incoming.close();
                                        }
                                        if (this.outgoing != null) {
                                            this.outgoing.close();
                                            return;
                                        }
                                        return;
                                    } catch (IOException e2) {
                                        return;
                                    }
                                } catch (Throwable th) {
                                    try {
                                        if (this.incoming != null) {
                                            this.incoming.close();
                                        }
                                        if (this.outgoing != null) {
                                            this.outgoing.close();
                                        }
                                    } catch (IOException e3) {
                                    }
                                }
                            }
                            ToClient.flush();
                        } else {
                            ToClient.write(buffer, 0, numberRead);
                            ToClient.flush();
                            if (debug) {
                                String build = new String(buffer, 0, numberRead).replace("\n","");
                                addLog(build.toString());
                            }
                        }
                    } else {
                        ToClient.write(buffer, 0, numberRead);
                        ToClient.flush();
                        if (debug) {
                            String build = new String(buffer, 0, numberRead).replace("\n","");
                            addLog(build.toString());
                        }
                    }
                }
            }
            FromClient.close();
            ToClient.close();
        } catch(Exception e){
            try {
                if (this.incoming != null) {
                    this.incoming.close();
                }
                if (this.outgoing != null) {
                    this.outgoing.close();
                }
            } catch (IOException e4) {
            }
        }
    }

	void sendHandshakeSuccess(Socket socket) {
		try {
			String respond = "HTTP/1.0 200 OK\r\n\r\n";
			socket.getOutputStream().write(respond.getBytes());
			socket.getOutputStream().flush();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

    void addLog(String log){
        Log.d("Proxy Thread", log);
    }

    public static void connect(Socket socket, Socket socket2) {
        ProxyThread sc1 = new ProxyThread(socket, socket2, true);
        ProxyThread sc2 = new ProxyThread(socket2, socket, false);
        sc1.setDaemon(true);
        sc1.start();
        sc2.setDaemon(true);
        sc2.start();
    }

}
