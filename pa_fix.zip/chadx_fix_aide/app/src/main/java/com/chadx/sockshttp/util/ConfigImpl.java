package com.chadx.sockshttp.util;

import android.content.Context;
import android.content.SharedPreferences;
import com.chadx.sockshttp.MyApplication;
import com.chadx.sockshttp.R;
import com.chadx.sockshttp.model.config;

public class ConfigImpl implements config 
{

	@Override
	public String getSNI() {
		return sp.getString("sniDataPreferences","");
	}

	public void setSNI(String s) {
		sp.edit().putString("sniDataPreferences", s).apply();
	}

	private Context mContext;

	@Override
	public String getUa()
	{
		// TODO: Implement this method
		String property = System.getProperty("http.agent");
        return property == null ? "Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.130 Safari/537.36" : property;
	}

	@Override
	public boolean isAutoReconnect()
	{
		return sp.getBoolean("isAutoReconnect",false);
	}


	@Override
	public String getHost()
	{
		return sp.getString("custom_server_addr","");
	}

	@Override
	public String getPort()
	{
		return sp.getString("custom_server_port","");
	}

	@Override
	public String getUser()
	{
		return sp.getString("ssh_username","");
	}

	@Override
	public String getPassword()
	{
		return sp.getString("ssh_password","");
	}

	@Override
	public String getPayload()
	{
		// TODO: Implement this method

		return sp.getString("netDataPreferences", "");

	}

	@Override
	public String getHttpHost()
	{
		// TODO: Implement this method

		return sp.getString("proxyPreferences","");

	}

	@Override
	public String getHttpPort()
	{
		// TODO: Implement this method

		return sp.getString("portPreferences", "");

	}

	public void setTunnelType(int i) {
		sp.edit().putInt("TunnelType", i).apply();
	}

	public int getTunnelType() {
		return sp.getInt("TunnelType", R.id.rbSSH);
	}

	public void setConType(int i) {
		sp.edit().putInt("ConnectionType", i).apply();
	}

	public int getConType() {
		return sp.getInt("ConnectionType", R.id.rbProxy);
	}

	public void isUsePayload(boolean z) {
		sp.edit().putBoolean("usePayload", z).apply();
	}

	public boolean isUsePayload() {
		return sp.getBoolean("usePayload", true);
	}

	public void setSSHHost(String s) {
		sp.edit().putString("custom_server_addr",s).apply();
	}

	public void setSSHPort(String s) {
		sp.edit().putString("custom_server_port",s).apply();
	}

	public void setSSHUser(String s) {
		sp.edit().putString("ssh_username",s).apply();
	}

	public void setSSHPass(String s) {
		sp.edit().putString("ssh_password", s).apply();
	}

	public void setPayload(String s) {
		sp.edit().putString("netDataPreferences",s).apply();
	}

	public void setSquidHost(String s) {
		sp.edit().putString("proxyPreferences",s).apply();
	}

	public void setSquidPort(String s) {
		sp.edit().putString("portPreferences",s).apply();
	}

	public void setConfigMessage(String s) {
		sp.edit().putString("cMess",s).apply();
	}

	public String getConfigMessage() {
		return sp.getString("cMess","");
	}

	public void isHaveMsg(boolean z) {
		sp.edit().putBoolean("haveMSG", z).apply();
	}

	public boolean isHaveMsg() {
		return sp.getBoolean("haveMSG", false);
	}

	public void isHaveConfig(boolean z) {
		sp.edit().putBoolean("ImportedConfig", z).apply();
	}

	public boolean isHaveConfig() {
		return sp.getBoolean("ImportedConfig", false);
	}

	private SharedPreferences sp;
	public ConfigImpl()
	{
		sp = MyApplication.getSharedPreferences();
	}
}
