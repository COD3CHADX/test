package com.chadx.sockshttp.model;

import android.view.View;

public interface OnUpdateLayout {
	void updateLayout(View view);
}
