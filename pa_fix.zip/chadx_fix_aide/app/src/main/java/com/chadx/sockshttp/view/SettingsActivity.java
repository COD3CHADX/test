package com.chadx.sockshttp.view;

import android.app.FragmentTransaction;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.CheckBoxPreference;
import android.preference.EditTextPreference;
import android.preference.Preference;
import android.preference.PreferenceFragment;
import android.preference.SwitchPreference;
import android.view.MenuItem;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.appcompat.widget.Toolbar;
import com.chadx.sockshttp.MainActivity;
import com.chadx.sockshttp.MyApplication;
import com.chadx.sockshttp.R;
import com.chadx.sockshttp.Service.SSHTunnelService;
import com.chadx.sockshttp.util.SecurePreferences;

public class SettingsActivity extends AppCompatActivity {

	private Toolbar toolbar;

	public static class SettingFragment extends PreferenceFragment implements SecurePreferences.OnSharedPreferenceChangeListener {
		private SharedPreferences mSecurePrefs;
		private CheckBoxPreference mDnsForwardPref;
		private CheckBoxPreference mEnableDnsPref;
		private EditTextPreference mPrimaryDnsPref;
		private EditTextPreference mSecondaryDnsPref;
		private SwitchPreference mSubnet;
		private SwitchPreference mTether;
        private SwitchPreference mShowNotif;
        private SwitchPreference mVibNotif;
        private CheckBoxPreference mUDPForwardPref;
        private EditTextPreference mUDPPref;
        private Preference ssh_settings;
        private Preference buffer;
        private CheckBoxPreference useKeepAlivePref;
        private CheckBoxPreference useCPUWakeLock;
        private SwitchPreference nightMode;
        private CheckBoxPreference mEnableReconnectPref;
        private CheckBoxPreference mTcpForwardPref;

		@Override
		public void onCreate(Bundle savedInstanceState) {
			super.onCreate(savedInstanceState);
            new MyApplication().init(getActivity());
			if (new MyApplication().isNightModeEnabled()) {
				AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
			} else {
				AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
			}
            addPreferencesFromResource(R.xml.settings);
			mSecurePrefs = new SecurePreferences(getActivity());
            mSecurePrefs = MyApplication.getSharedPreferences();       

            mShowNotif = (SwitchPreference) findPreference("show_notification");
            mVibNotif = (SwitchPreference) findPreference("vibrate");  


		  	mDnsForwardPref = (CheckBoxPreference) findPreference("dns_forwarder_key");  
            mEnableDnsPref = (CheckBoxPreference) findPreference("enable_dns_key");
			//   mEnableDnsPref.setDependency("dns_forwarder_key");		
            mEnableReconnectPref = (CheckBoxPreference) findPreference("auto_reconnect_key");
            // 
            useKeepAlivePref = (CheckBoxPreference) findPreference("useKeepAlive"); 
            useCPUWakeLock = (CheckBoxPreference) findPreference("useWakeLock");  
            mUDPForwardPref = (CheckBoxPreference) findPreference("udp_forwarder_key");  
            mTcpForwardPref = (CheckBoxPreference) findPreference("tcp_forwarder_key");  

            mUDPPref = (EditTextPreference) findPreference("udp_forward");
            mUDPPref.setSummary(mSecurePrefs.getString("udp_forward", ""));
		 	mUDPPref.setDependency("udp_forwarder_key");	

			mPrimaryDnsPref = (EditTextPreference) findPreference("custom_primary_dns");
            mPrimaryDnsPref.setSummary(mSecurePrefs.getString("custom_primary_dns", "8.8.8.8"));
			mPrimaryDnsPref.setDependency("enable_dns_key");	

			mSecondaryDnsPref = (EditTextPreference) findPreference("custom_secondary_dns");
            mSecondaryDnsPref.setSummary(mSecurePrefs.getString("custom_secondary_dns", "8.8.4.4"));        
			mSecondaryDnsPref.setDependency("enable_dns_key");

            ssh_settings = findPreference("ssh_intent");
            ssh_settings.setOnPreferenceClickListener(new Preference.OnPreferenceClickListener() {
                    @Override
                    public boolean onPreferenceClick(Preference preference) {
                        getActivity().startActivity(new Intent(getActivity(), SSHTunnelSettings.class));
                        return true;
                    }
				});
			if(mDnsForwardPref.isChecked()){
				mEnableDnsPref.setEnabled(true);
				if(mEnableDnsPref.isChecked()){
					mPrimaryDnsPref.setEnabled(true);
					mSecondaryDnsPref.setEnabled(true);
				}else{
					mPrimaryDnsPref.setEnabled(false);
					mSecondaryDnsPref.setEnabled(false);
				}
			}else{
				mEnableDnsPref.setEnabled(false);
				mPrimaryDnsPref.setEnabled(false);
				mSecondaryDnsPref.setEnabled(false);
			}
			nightMode = (SwitchPreference) findPreference("night_mode");
			mSubnet = (SwitchPreference) findPreference("subnet_routing");
			mTether = (SwitchPreference) findPreference("allow_tethering");
			mTether.setDependency("subnet_routing");
			//	mLan.setDependency("subnet_routing");		
			if(mSubnet.isChecked()){
				mTether.setEnabled(true);
				//	mLan.setEnabled(true);
			}else{
				mTether.setEnabled(false);
				//	mLan.setEnabled(false);

			}
            buffer = findPreference("buffer_size");
            buffer.setSummary(new StringBuffer().append("Send: ").append(mSecurePrefs.getString("buffer_send", "16384")).append(" | Receive: ").append(mSecurePrefs.getString("buffer_receive", "32768")));
            buffer.setOnPreferenceClickListener(new Preference.OnPreferenceClickListener() {
                    @Override
                    public boolean onPreferenceClick(Preference preference) {
                        new BufferSizeDialog(getActivity(), buffer).show();
                        return true;
                    }
				});
            if (SSHTunnelService.isSSHRunning){
				//mShowNotif.setEnabled(false);
                mDnsForwardPref.setEnabled(false);
                mEnableDnsPref.setEnabled(false);
				//   useKeepAlivePref.setEnabled(false);
				//   useCPUWakeLock.setEnabled(false);
                mUDPForwardPref.setEnabled(false);
                mPrimaryDnsPref.setEnabled(false);
                mSecondaryDnsPref.setEnabled(false);
                mSubnet.setEnabled(false);
                buffer.setEnabled(false);

            }   
		}

		@Override
		public void onSharedPreferenceChanged(SharedPreferences sharedPreferences, String key) {
			switch (key) {
				case "custom_primary_dns":
					mPrimaryDnsPref.setSummary(mSecurePrefs.getString("custom_primary_dns", "8.8.8.8"));           
					break;
                case "custom_secondary_dns":
					mSecondaryDnsPref.setSummary(mSecurePrefs.getString("custom_secondary_dns", "8.8.4.4"));                 
					break;
                case "udp_forward":
                    mUDPPref.setSummary(mSecurePrefs.getString("udp_forward", "127.0.0.1:7300"));		
                    break;
                case "night_mode":
					new MyApplication().init(getActivity());
                    if(nightMode.isChecked()){
                        new MyApplication().setIsNightModeEnabled(true);
                        Intent intent = new Intent(getActivity(), MainActivity.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                        getActivity().finishAndRemoveTask();
                        startActivity(intent);  
                    }else{                     
                        new MyApplication().setIsNightModeEnabled(false);
                        Intent intent = new Intent(getActivity(), MainActivity.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                        getActivity().finishAndRemoveTask();
                        startActivity(intent);  
                    } 
                    break;
				case "subnet_routing":
					if(mSubnet.isChecked()){
						mTether.setEnabled(true);
						//	mLan.setEnabled(true);
					}else{
						mTether.setEnabled(false);
						//	mLan.setEnabled(false);
					}
					break;		
                case "udp_forwarder_key":
					if(mUDPForwardPref.isChecked()){
						mUDPPref.setEnabled(true);
					}  else{
						mUDPPref.setEnabled(false);                                         
					}  
					break;
				case "dns_forwarder_key":
					if(mDnsForwardPref.isChecked()){
						mEnableDnsPref.setEnabled(true);
						if(mEnableDnsPref.isChecked()){
							mPrimaryDnsPref.setEnabled(true);
							mSecondaryDnsPref.setEnabled(true);
						}else{
							mPrimaryDnsPref.setEnabled(false);
							mSecondaryDnsPref.setEnabled(false);
						}
					}else{
						mEnableDnsPref.setEnabled(false);
						mPrimaryDnsPref.setEnabled(false);
						mSecondaryDnsPref.setEnabled(false);
					}
					break;
				case "enable_dns_key":
					if(mEnableDnsPref.isChecked()){
						mPrimaryDnsPref.setEnabled(true);
						mSecondaryDnsPref.setEnabled(true);
					}else{
						mPrimaryDnsPref.setEnabled(false);
						mSecondaryDnsPref.setEnabled(false);
					}
					break;                 
			}		
		}

		@Override
		public void onResume() {
			super.onResume();
			mSecurePrefs.registerOnSharedPreferenceChangeListener(this);
		}

		@Override
		public void onPause() {
			super.onPause();
			mSecurePrefs.unregisterOnSharedPreferenceChangeListener(this);
		}
	}

    @Override
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
		setContentView(R.layout.fragment_prefs);
		toolbar =  (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
		toolbar.setTitle("Settings");
        FragmentTransaction beginTransaction = getFragmentManager().beginTransaction();
        beginTransaction.replace(R.id.container, new SettingFragment());
        beginTransaction.commit();
        setupActionBar();
    }
	private void setupActionBar() {
		ActionBar actionBar = getSupportActionBar();
		if (actionBar != null) {
			// Show the Up button in the action bar.
			actionBar.setDisplayHomeAsUpEnabled(true);
			//actionBar.setHomeAsUpIndicator(R.drawable.abc_ic_clear_material);
		}
	}
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
        }
        return super.onOptionsItemSelected(item);
    }
}



