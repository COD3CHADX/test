package com.chadx.sockshttp.view;

import android.app.Fragment;
import android.content.ClipData;
import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.Toast;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.chadx.sockshttp.logger.LogView;
import com.chadx.sockshttp.logger.Log;
import com.chadx.sockshttp.logger.LogWrapper;
import com.chadx.sockshttp.logger.MessageOnlyLogFilter;


public class LogFragment extends Fragment 
{
    private static LogView mLogView;
    private LinearLayout mScrollView;

    private FloatingActionButton fab;
    @Override
    public void onCreate(Bundle bundle)
    {
        super.onCreate(bundle);
        setHasOptionsMenu(true);
    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
    {
        this.mScrollView = new LinearLayout(getActivity());
        LayoutParams scrollParams = new LayoutParams(-1, -1);
        this.mScrollView.setLayoutParams(scrollParams);
        this.mLogView = new LogView(getActivity());
        LayoutParams logParams = new LayoutParams(scrollParams);
        logParams.height = logParams.WRAP_CONTENT;
        this.mLogView.setLayoutParams(logParams);
        this.mLogView.setClickable(true);
		//mScrollView.fullScroll(130);
        this.mLogView.setFocusable(true);
        this.mScrollView.addView(this.mLogView);
        //fab = (FloatingActionButton) 
        return this.mScrollView;

    }
    public static LogView getLogView()
    {
        return mLogView;
    }

    public static void copyToClipboard(Context context, String str)
    {
        if (android.os.Build.VERSION.SDK_INT >= 11)
        {
            ((android.content.ClipboardManager) context.getSystemService("clipboard")).setPrimaryClip(ClipData.newPlainText("CDCEVPN-log", str));
        }
        else
        {
            ((android.text.ClipboardManager) context.getSystemService("clipboard")).setText(str);
        }
        Toast.makeText(context, "Copy to Clipboard", 0).show();
    }

    public static void clear()
    {
        LogView.arrayList.clear();
        addLog(new StringBuffer().append("Running on ").append(Build.BRAND).append(" ").append(Build.MODEL).append(" (").append(Build.PRODUCT).append(") ").append(Build.MANUFACTURER).append(", Android API ").append(Build.VERSION.SDK).toString());
        addLog("Application version: " + "1.0.0 (Build 15) Unofficial Release");
    }

    public static void addLog(String str)
    {
        Log.i("EasySSH", str);
    }

    public static void addLog(String tag, String str)
    {
        Log.i(tag, str);
    }

    public void onStart()
    {
        super.onStart();
        LogWrapper logWrapper = new LogWrapper();
        Log.setLogNode(logWrapper);
        MessageOnlyLogFilter msgFilter = new MessageOnlyLogFilter();
        logWrapper.setNext(msgFilter);
        // this.logFragment = (LogFragment) getSupportFragmentManager().findFragmentById(R.id.log_window);
        msgFilter.setNext(getLogView());

    }
}

