package com.chadx.sockshttp;

import com.chadx.sockshttp.R;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;


public class Login extends Activity
{


    EditText email,password;



	public static final boolean isLoaded = false;

	private SharedPreferences prefs;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

		prefs = PreferenceManager.getDefaultSharedPreferences(this);

		setContentView(R.layout.activity_login);

        //top_curve = (ImageView) findViewById(R.id.top_curve);
        email = (EditText) findViewById(R.id.email);

        password = (EditText) findViewById(R.id.password);


		email.setText(prefs.getString("myusername2",""));
		password.setText(prefs.getString("mypassword2",""));

		if(!prefs.getString("VPN_USERNAME","").isEmpty() && !prefs.getString("VPN_PASSWORD","").isEmpty()){
			startActivity(new Intent(this,MainActivity.class));
		}

    }



	@Override
	public void onBackPressed()
	{
		finish();
		super.onBackPressed();
	}

	public void register(View view)
	{
		email.setText("");
		password.setText("");
	}



	public void viewWeb(String str)
	{
		if (str.isEmpty()) {
			//showToast("Link is empty!");
		} else {
			startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(str)));
		}
	}


	/*
	 public void register(View view) {
	 startActivity(new Intent(this,Registration.class));
	 }
	 */
    public void loginButton(View view) {

		finish();
		String user = email.getText().toString();
		String pass = password.getText().toString();
		if(!user.isEmpty() && !pass.isEmpty()){
			prefs.edit().putString("VPN_USERNAME",user).apply();
			prefs.edit().putString("VPN_PASSWORD",pass).apply();

			prefs.edit().putString("myusername2",user).apply();
			prefs.edit().putString("mypassword2",pass).apply();

			startActivity(new Intent(this,MainActivity.class));
		}else{
			Toast.makeText(this, "Username/Password must be not empty!",0).show();
		}

    }

	/*public void web(View v)
	{
		startActivity(new Intent(getApplicationContext(), WebViewActivity.class));

	}

*/

}


