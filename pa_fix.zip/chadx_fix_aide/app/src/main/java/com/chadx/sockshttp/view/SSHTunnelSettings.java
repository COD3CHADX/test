package com.chadx.sockshttp.view;


import android.app.FragmentTransaction;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.CheckBoxPreference;
import android.preference.EditTextPreference;
import android.preference.PreferenceFragment;
import android.view.MenuItem;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.appcompat.widget.Toolbar;
import com.chadx.sockshttp.MyApplication;
import com.chadx.sockshttp.R;
import com.chadx.sockshttp.Service.SSHTunnelService;
import com.chadx.sockshttp.util.ConfigImpl;
import com.chadx.sockshttp.util.SecurePreferences;
import com.chadx.sockshttp.util.Utils;

public class SSHTunnelSettings extends AppCompatActivity {

	private Toolbar toolbar;

	public static class SSHFragment extends PreferenceFragment  implements SecurePreferences.OnSharedPreferenceChangeListener   {

	    private EditTextPreference localport;
        private EditTextPreference dynamicport;
        private EditTextPreference hostText;
        private EditTextPreference portText;
        private EditTextPreference userText;
        private EditTextPreference passwordText;
        private SharedPreferences mSecurePrefs;
        private CheckBoxPreference mUpstreamPref;
        private EditTextPreference upstreamPref;
        private CheckBoxPreference mCompressionPref;

		@Override
		public void onSharedPreferenceChanged(SharedPreferences settings, String key) {    
			switch (key){
				case "custom_server_addr":
					if(mSecurePrefs.getString("custom_server_addr", "").equals("")){
						hostText.setSummary("The hostname of SSH Server");		
					} else {
						hostText.setSummary(mSecurePrefs.getString("custom_server_addr", ""));		 
					}			 
					break; 

				case "custom_server_port":
					if(mSecurePrefs.getString("custom_server_port", "").equals("")){
						portText.setSummary("The port of SSH Server");		
					} else {
						portText.setSummary(mSecurePrefs.getString("custom_server_port", "22"));		 
					} 
					break;

				case "ssh_username":
					if(mSecurePrefs.getString("ssh_username", "").equals("")){
						userText.setSummary("Enter the username of the SSH Server");		
					} else {
						userText.setSummary(mSecurePrefs.getString("ssh_username", ""));		 
					} 
					break; 

				case "ssh_password":
					if(mSecurePrefs.getString("ssh_password", "").equals("")){
						passwordText.setSummary("Enter the password of the SSH Server");		
					} else {
						passwordText.setSummary(mSecurePrefs.getString("ssh_password", "").replace(mSecurePrefs.getString("ssh_password", ""), Utils.allStar(mSecurePrefs.getString("ssh_password", ""))));		 
					} 
					break; 

				case "local_port":
					localport.setSummary(mSecurePrefs.getString("local_port", ""));
					break;

				case "dynamic_port":
					dynamicport.setSummary(mSecurePrefs.getString("dynamic_port", ""));
					break; 

				case "isUpstreamProxy":
					if(mUpstreamPref.isChecked()){
						upstreamPref.setEnabled(true);               
					} else {
						upstreamPref.setEnabled(false);
					}
					break;
				case "upstreamProxy":
					if(mSecurePrefs.getString("upstreamProxy", "").equals("")){
						upstreamPref.setSummary(getActivity().getString(R.string.upstream_proxy_summary));
					} else {
						upstreamPref.setSummary(mSecurePrefs.getString("upstreamProxy", "127.0.0.1:8989"));  
					}
					break;     
			}

		}  

		@Override
		public void onCreate(Bundle savedInstanceState) {
			super.onCreate(savedInstanceState);
			addPreferencesFromResource(R.xml.ssh_settings);
			new MyApplication().init(getActivity());
			if (new MyApplication().isNightModeEnabled()) {
				AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
			} else {
				AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
			}
			mSecurePrefs = new SecurePreferences(getActivity());
			mSecurePrefs = MyApplication.getSharedPreferences();

			hostText = (EditTextPreference) findPreference("custom_server_addr");
			hostText.setSummary(mSecurePrefs.getString("custom_server_addr", "")); 

			if(mSecurePrefs.getString("custom_server_addr", "").equals("")){
				hostText.setSummary("The hostname of SSH Server");		
			} else {
				hostText.setSummary(mSecurePrefs.getString("custom_server_addr", ""));		 
			}

			portText = (EditTextPreference) findPreference("custom_server_port");
			portText.setSummary(mSecurePrefs.getString("custom_server_port", ""));

			if(mSecurePrefs.getString("custom_server_port", "").equals("")){
				portText.setSummary("The port of SSH Server");		
			} else {
				portText.setSummary(mSecurePrefs.getString("custom_server_port", "22"));		 
			} 

			userText = (EditTextPreference) findPreference("ssh_username");
			userText.setSummary(mSecurePrefs.getString("ssh_username", ""));

			if(mSecurePrefs.getString("ssh_username", "").equals("")){
				userText.setSummary("Enter the username of the SSH Server");		
			} else {
				userText.setSummary(mSecurePrefs.getString("ssh_username", ""));		 
			} 

			passwordText = (EditTextPreference) findPreference("ssh_password");
			passwordText.setSummary(mSecurePrefs.getString("ssh_password", ""));

			if(mSecurePrefs.getString("ssh_password", "").equals("")){
				passwordText.setSummary("Enter the password of the SSH Server");		
			} else {
				passwordText.setSummary(mSecurePrefs.getString("ssh_password", "").replace(mSecurePrefs.getString("ssh_password", ""), Utils.allStar(mSecurePrefs.getString("ssh_password", ""))));		 
			} 

			localport = (EditTextPreference) findPreference("local_port");
			localport.setSummary(mSecurePrefs.getString("local_port", ""));

			dynamicport = (EditTextPreference) findPreference("dynamic_port");
			dynamicport.setSummary(mSecurePrefs.getString("dynamic_port", ""));

			mUpstreamPref = (CheckBoxPreference) findPreference("isUpstreamProxy");  
			mCompressionPref = (CheckBoxPreference) findPreference("data_compression_key");  

			upstreamPref = (EditTextPreference) findPreference("upstreamProxy");
			upstreamPref.setSummary(mSecurePrefs.getString("upstreamProxy", "127.0.0.1:8989"));
			upstreamPref.setDependency("isUpstreamProxy");    
			if(SSHTunnelService.isSSHRunning){
				hostText.setEnabled(false);
				portText.setEnabled(false);
				userText.setEnabled(false);
				passwordText.setEnabled(false);
				localport.setEnabled(false);
				dynamicport.setEnabled(false);
				mUpstreamPref.setEnabled(false);
				upstreamPref.setEnabled(false);
				mCompressionPref.setEnabled(false);
			}  
			if(new ConfigImpl().isHaveConfig()){ 
				userText.setSummary("Locked");
				userText.setEnabled(false);
				portText.setSummary("Locked");
				portText.setEnabled(false);
				hostText.setSummary("Locked");
				hostText.setEnabled(false);
				passwordText.setSummary("Locked");
				passwordText.setEnabled(false);
			}
		}


	    @Override
        public void onResume() {
            super.onResume();
            mSecurePrefs.registerOnSharedPreferenceChangeListener(this);
        }

        @Override
        public void onPause() {
            super.onPause();
            mSecurePrefs.unregisterOnSharedPreferenceChangeListener(this);
		}
	}

    @Override
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.fragment_prefs);
		toolbar =  (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        FragmentTransaction beginTransaction = getFragmentManager().beginTransaction();
        beginTransaction.replace(R.id.container, new SSHFragment());
        beginTransaction.commit();
        setupActionBar();
    }
    private void setupActionBar() {
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            // Show the Up button in the action bar.
			actionBar.setDisplayHomeAsUpEnabled(true);
			//    actionBar.setHomeAsUpIndicator(R.drawable.abc_ic_clear_material);
        }
	}
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
			onBackPressed();
        }
        return super.onOptionsItemSelected(item);
    } 
}

    



