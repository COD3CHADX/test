package com.chadx.sockshttp.view;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.view.LayoutInflater;
import android.view.View;
import com.google.android.material.textfield.TextInputEditText;
import com.chadx.sockshttp.MainActivity;
import com.chadx.sockshttp.MyApplication;
import com.chadx.sockshttp.R;

public class SquidSetupDialog
{
    private SharedPreferences  sp;
	private Context context;

    public SquidSetupDialog(Context c) {
		context = c;
		new MyApplication().init(c);
        sp = MyApplication.getSharedPreferences();
		showDialog();
    }

	void showDialog() {
		AlertDialog.Builder adb = new AlertDialog.Builder(context,R.style.Theme_MaterialComponents_Light_Dialog_Alert );
        LayoutInflater i = LayoutInflater.from(context);
		View view = i.inflate(R.layout.dialog_squid,null);
		final TextInputEditText etRemoteProxy = (TextInputEditText) view.findViewById(R.id.etRemoteProxy);
		final TextInputEditText etRemotePort = (TextInputEditText) view.findViewById(R.id.etRemotePort);
		etRemoteProxy.setText(sp.getString("proxyPreferences",""));
		etRemotePort.setText(sp.getString("portPreferences",""));
        adb.setCancelable(false);
        adb.setTitle("Proxy Settings");
        adb.setMessage("HTTP Proxy (eg: Squid)");
        adb.setView(view);
        adb.setPositiveButton("SAVE", new DialogInterface.OnClickListener(){
                @Override
                public void onClick(DialogInterface p1, int p2)
                {
					sp.edit().putString("proxyPreferences", etRemoteProxy.getText().toString()).apply();
					sp.edit().putString("portPreferences", etRemotePort.getText().toString()).apply();
					MainActivity.updateSquid();
					p1.dismiss();
                }
            });
        adb.setNegativeButton("Cancel", null);
        adb.setNeutralButton("Reset", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface p1, int p2)
                {
					sp.edit().putString("proxyPreferences", "").apply();
					sp.edit().putString("portPreferences", "").apply();
					MainActivity.tvSquid.setText("HTTP Proxy (eg: Squid)");
					p1.dismiss();
                }
            });
		AlertDialog alert = adb.create();
        alert.getWindow().setBackgroundDrawableResource(R.drawable.popup_background);
		alert.show();
	}

}
