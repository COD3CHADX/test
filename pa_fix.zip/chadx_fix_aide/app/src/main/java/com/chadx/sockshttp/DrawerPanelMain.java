package com.chadx.sockshttp;

import static androidx.core.content.ContextCompat.startActivity;

import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.widget.Toolbar;

import com.google.android.material.navigation.NavigationView;
import android.content.pm.PackageInfo;
import com.chadx.sockshttp.util.Utils;
import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.NonNull;

import android.net.Uri;
import android.view.MenuItem;
import android.widget.Toast;
import android.os.Build;
import android.content.Intent;

import androidx.core.view.GravityCompat;
import com.chadx.sockshttp.activities.ConfigGeralActivity;
import com.chadx.sockshttp.activities.AboutActivity;
import com.chadx.sockshttp.view.HTTPGenerator;


public class DrawerPanelMain
        implements NavigationView.OnNavigationItemSelectedListener
{
    private AppCompatActivity mActivity;

    public DrawerPanelMain(AppCompatActivity activity) {
        mActivity = activity;
    }


    private DrawerLayout drawerLayout;
    private ActionBarDrawerToggle toggle;

    /*public void setDrawer(Toolbar toolbar) {
        NavigationView drawerNavigationView = (NavigationView) mActivity.findViewById(R.id.drawerNavigationView);
        drawerLayout = (DrawerLayout) mActivity.findViewById(R.id.drawerLayoutMain);

        // set drawer
        toggle = new ActionBarDrawerToggle(mActivity,
                drawerLayout, toolbar, R.string.open, R.string.cancel);

        drawerLayout.setDrawerListener(toggle);

        toggle.syncState();

        // set app info



        // set navigation view
        drawerNavigationView.setNavigationItemSelectedListener(this);
    }*/

    public ActionBarDrawerToggle getToogle() {
        return toggle;
    }

    public DrawerLayout getDrawerLayout() {
        return drawerLayout;
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();

        switch(id)
        {
      /*      case R.id.channel:
                Intent w = new Intent("https://m.me/adik016");
                break;

			case R.id.payloadGenerator:
				if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
                    drawerLayout.closeDrawers();
                }
				Intent gago = new Intent(mActivity, HTTPGenerator.class);
                mActivity.startActivity(gago);	
				break;
				
            case R.id.notif:
                Intent intent = new Intent(mActivity, Login.class);
                mActivity.startActivity(intent);
                break;

            case R.id.devz:
                if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
                    drawerLayout.closeDrawers();
                }
                Intent aboutIntent = new Intent(mActivity, AboutActivity.class);
                mActivity.startActivity(aboutIntent);
                break;

            case R.id.logger:
                if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
                    drawerLayout.closeDrawers();
                }
                Intent intent7 = new Intent(mActivity, ChadXLogger.class);
                mActivity.startActivity(intent7);
                break;
*/
        }

        return true;
    }

}


