package com.chadx.sockshttp.core;


import android.content.SharedPreferences;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.channels.SocketChannel;
import java.security.SecureRandom;
import javax.net.ssl.HandshakeCompletedEvent;
import javax.net.ssl.HandshakeCompletedListener;
import javax.net.ssl.KeyManager;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import com.chadx.sockshttp.MyApplication;
import com.chadx.sockshttp.view.LogFragment;
import com.chadx.sockshttp.util.ConfigImpl;

public class SSLService {
    private Socket input;
    public SSLSocket b;
    public Socket socket;
    private String addres;
    private String serv_port;
    private String spoof_host;
    private SharedPreferences sp;

    public SSLService(Socket in, String server_addr, String server_port, String spoof){
        input = in;
        addres = server_addr;
        serv_port = server_port;
        spoof_host = spoof;
        sp = MyApplication.getSharedPreferences();
    }

    public Socket socket() {
        try {
            String readRequestHeader = readRequestHeader();
            if (readRequestHeader == null || !readRequestHeader.contains(":")) {
                addLog(new StringBuffer().append("Invalid request: ").append(readRequestHeader).toString());
                return (Socket) null;
            }
            String host = readRequestHeader.split(":")[0];
            int port = Integer.parseInt(readRequestHeader.split(":")[1]);
            sendForwardSuccess(input);
            socket = SocketChannel.open().socket();
            socket.connect(new InetSocketAddress(host, port));
            if(socket.isConnected()){
                socket = doSSLHandshake2(addres, spoof_host, Integer.parseInt(serv_port));
            }
            return socket;
        } catch (Exception e) {
            addLog(new StringBuffer().append("Exception in proxy thread: ").append(e.getMessage()).toString());
            return null;
        }
    }


    private String readRequestHeader() throws IOException {
        Reader reader = new InputStreamReader(input.getInputStream());
        BufferedReader lineReader = new BufferedReader(reader);
        String request = null;
        String line;
        while ((line = lineReader.readLine()) != null) {
            if (line.startsWith("CONNECT") && request == null) {
                request = line.split(" ")[1];
            }
            if (line.length() == 0) {
                return request;
            }
        }
        return null;
    }

    private void sendForwardSuccess(Socket socket) throws IOException {
        String respond = "HTTP/1.1 200 OK\r\n\r\n";
        socket.getOutputStream().write(respond.getBytes());
        socket.getOutputStream().flush();
    }

    private Socket doSSLHandshake2(String host, String sni, int port) throws IOException {
        TrustManager[] trustAllCerts = new TrustManager[] {
            new X509TrustManager() {
                public java.security.cert.X509Certificate[] getAcceptedIssuers()
                {
                    return null;
                }
                public void checkClientTrusted(
                    java.security.cert.X509Certificate[] certs, String authType)
                {
                }
                public void checkServerTrusted(
                    java.security.cert.X509Certificate[] certs, String authType)
                {
                }
            }
        };
        try {
            SSLContext sSLContext = SSLContext.getInstance("TLS");
            KeyManager[] keyManagerArr = (KeyManager[]) null;
            sSLContext.init(keyManagerArr, trustAllCerts, new SecureRandom());
            SSLSocket socket = (SSLSocket) sSLContext.getSocketFactory().createSocket(host, port);
            setSNIHost(sSLContext.getSocketFactory(), socket, sni);
            if(sp.getString("tls_version_min_override", "default").equals("default")){
                socket.setEnabledProtocols(socket.getEnabledProtocols());
            }else{
                socket.setEnabledProtocols(new String[] {sp.getString("tls_version_min_override", "default")});
            }
            socket.addHandshakeCompletedListener(new mHandshakeCompletedListener(host, port, socket));
            return socket;
        }
		catch (Exception e) {
            IOException iOException = new IOException(new StringBuffer().append("Could not do SSL handshake: ").append(e).toString());
            throw iOException;
        }
    }

    private void setSNIHost(final SSLSocketFactory factory, final SSLSocket socket, final String hostname) {
        if (factory instanceof android.net.SSLCertificateSocketFactory && android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.JELLY_BEAN_MR1) {
            ((android.net.SSLCertificateSocketFactory)factory).setHostname(socket, hostname);
        } else {
            try {
                socket.getClass().getMethod("setHostname", String.class).invoke(socket, hostname);
                if(!new ConfigImpl().isHaveConfig()){   
                    addLog(new StringBuffer().append("Setting up SNI Address: ").append(hostname).toString());
				}
			} catch (Throwable e) {
                // ignore any error, we just can't set the hostname...
            }
        }
    }

    class mHandshakeCompletedListener implements HandshakeCompletedListener {
        private final String val$host;
        private final int val$port;
        private final SSLSocket val$sslSocket;

        mHandshakeCompletedListener( String str, int i, SSLSocket sSLSocket) {
            this.val$host = str;
            this.val$port = i;
            this.val$sslSocket = sSLSocket;
        }

        public void handshakeCompleted(HandshakeCompletedEvent handshakeCompletedEvent) {
            addLog(new StringBuffer().append("<b>Established ").append(handshakeCompletedEvent.getSession().getProtocol()).append(" connection ").append("using ").append(handshakeCompletedEvent.getCipherSuite()).append("</b>").toString());
            addLog("SSL: Using cipher " + handshakeCompletedEvent.getSession().getCipherSuite());
            addLog("SSL: Using protocol " + handshakeCompletedEvent.getSession().getProtocol());
            addLog("SSL: Handshake finished");
        }
    }

    void addLog(String str){
        LogFragment.addLog(str);
    }

}

