package com.chadx.sockshttp.Service;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.net.VpnService;
import android.os.Binder;
import android.os.Build;
import android.os.IBinder;
import android.os.ParcelFileDescriptor;
import android.os.PowerManager;
import android.os.PowerManager.WakeLock;
import android.system.OsConstants;
import android.text.TextUtils;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.URL;
import java.util.Collection;
import java.util.Locale;
import com.chadx.ultrasshservice.tunnel.vpn.NetworkSpace;
import com.chadx.ultrasshservice.tunnel.vpn.Tun2Socks;
import com.chadx.ultrasshservice.tunnel.vpn.Pdnsd;
import com.chadx.sockshttp.MyApplication;
import com.chadx.ultrasshservice.tunnel.vpn.CIDRIP;
import com.chadx.sockshttp.util.ConfigImpl;
import com.chadx.sockshttp.util.Utils;
import com.chadx.sockshttp.logger.Log;

public class archivalservice extends VpnService implements Runnable {

    public static boolean isRunning = false;
    public String VPN_START = "START";
    public String VPN_STOP = "STOP";
    private Thread mThread;
    public static final String LOCAL_SERVER_ADDRESS = "127.0.0.1";
    public static final String LOCAL_SERVER_PORT = "1080";
    private final IBinder binder = new mLocalBinder();
    private int mMtu = 8192;
    private ParcelFileDescriptor tunFd;
    private NetworkSpace mRoutes;
    private SharedPreferences sp;
    private SharedPreferences dsp;
    private SharedPreferences a;
    WakeLock wakeLock;
    private Thread startKeepAlive;
    private VpnService.Builder c;
    public static final String LOCAL_ADDR = "1.1.1.1";
    public static final String LOCAL_DNS = "240.0.0.1";
	private static final String VPN_INTERFACE_NETMASK = "255.255.255.0";
	private static final int DNS_RESOLVER_PORT = 53;
    private VPNUtils.PrivateAddress mPrivateAddress;
    private String mRouter;
    private Tun2Socks mTun2Socks;
	private Pdnsd mPdnsd;

    public class mLocalBinder extends Binder   {
        public archivalservice getService()  {
            return archivalservice.this;
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        String action = intent.getAction();
        if (action != null && action.equals(SERVICE_INTERFACE))
        {
            return super.onBind(intent);
        }
        return binder;
    }

    @Override
    public void onCreate()  {    
        super.onCreate();
        a = MyApplication.getSharedPreferences();
        sp = MyApplication.getSharedPreferences();
        dsp = MyApplication.getSharedPreferences();
        mRoutes = new NetworkSpace();
    }

    public String a(String str) {
        HttpURLConnection httpURLConnection;
        StringBuilder stringBuilder;
        Exception e;
        OutOfMemoryError e2;
        Throwable th;
        try {
            httpURLConnection = (HttpURLConnection) new URL(str).openConnection();
            try {
                httpURLConnection.setConnectTimeout(30000);
                httpURLConnection.setReadTimeout(30000);
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(httpURLConnection.getInputStream()));
                StringBuilder stringBuilder2 = new StringBuilder();
                while (true) {
                    String readLine = bufferedReader.readLine();
                    if (readLine == null) {
                        break;
                    }
                    stringBuilder2.append(readLine);
                    stringBuilder2.append("\n");
                }
                bufferedReader.close();
                httpURLConnection.disconnect();
                stringBuilder = new StringBuilder();
                stringBuilder.append(stringBuilder2.length() / 1024);
                stringBuilder.append("K - HTTP: ");
                stringBuilder.append(str);
                //  addLog(stringBuilder.toString());
                String stringBuilder3 = stringBuilder2.toString();
                if (httpURLConnection != null) {
                    try {
                        httpURLConnection.disconnect();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }
                }
                return stringBuilder3;
            } catch (Exception e4) {
                e = e4;
                stringBuilder = new StringBuilder();
                stringBuilder.append("Error Parsing: ");
                stringBuilder.append(str);
                Log.d("KeepAliveService", stringBuilder.toString());
                e.printStackTrace();
                if (httpURLConnection != null) {
                    httpURLConnection.disconnect();
                }
                return null;
            } catch (OutOfMemoryError e5) {
                e2 = e5;
                try {
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("Error Parsing: ");
                    stringBuilder.append(str);
                    Log.d("KeepAliveService", stringBuilder.toString());
                    e2.printStackTrace();
                    if (httpURLConnection != null) {
                        try {
                            httpURLConnection.disconnect();
                        } catch (Exception e32) {
                            e32.printStackTrace();
                        }
                    }
                    return null;
                } catch (Throwable th2) {
                    th = th2;
                    if (httpURLConnection != null) {
                        try {
                            httpURLConnection.disconnect();
                        } catch (Exception e6) {
                            e6.printStackTrace();
                        }
                    }
                    throw th;
                }
            }
        } catch (Exception e7) {
            e = e7;
            httpURLConnection = null;
            stringBuilder = new StringBuilder();
            stringBuilder.append("Error Parsing: ");
            stringBuilder.append(str);
            Log.d("KeepAliveService", stringBuilder.toString());
            e.printStackTrace();
            if (httpURLConnection != null) {
                httpURLConnection.disconnect();
            }
            return null;
        } catch (OutOfMemoryError e8) {
            e2 = e8;
            httpURLConnection = null;
            stringBuilder = new StringBuilder();
            stringBuilder.append("Error Parsing: ");
            stringBuilder.append(str);
            Log.d("KeepAliveService", stringBuilder.toString());
            e2.printStackTrace();
            if (httpURLConnection != null) {
                httpURLConnection.disconnect();
            }
            return null;
        } catch (Throwable th3) {
            th = th3;
            httpURLConnection = null;
            if (httpURLConnection != null) {
                httpURLConnection.disconnect();
            }

        }
        return null;
    }

    private void startKeepAlive() {
        startKeepAlive = new Thread(new Runnable() {                     
                public void run() {
                    String a = a("https://www.graniteapps.net/ping");
                    String str = "<b>KeepAlive Connected</b>";
                    if (a == null) {
                        str = "KeepAlive not connected";
                    } else if (!a.contains("ed443caad83f10c8c03d5c3fd94d21128a190c353e46e04f9e63390119e3246d")) {
                        str = "Restricted";
                    }
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("");
                    stringBuilder.append(str);
                    Log.d("KeepAliveService", stringBuilder.toString());
                    addLog(stringBuilder.toString());
                }
            });
        startKeepAlive.start();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent.getAction();
        if (action == VPN_START) {
            if (mThread != null) {
                mThread.interrupt();
            }
            mThread = new Thread(this, "TunnelVPN Service");
            mThread.start();
        }
        else if (action == VPN_STOP) {
            onDisconnect();
            stopSelf();

        }

        return START_NOT_STICKY;
    }

    public void onRevoke() {
        super.onRevoke();
        if (SSHTunnelService.isSSHRunning) {
            startService(new Intent(this, SSHTunnelService.class).setAction("STOP"));
        }
        onDisconnect();
    }
    @Override
    public void run()  {
        try {
            if (!establishVpnConntection())   {
                addLog("Failed to establish VPN");
                return;
            }  
            boolean dnsForward = dsp.getBoolean("dns_forwarder_key", false);
            startVpnSocks(dnsForward, "127.0.0.1:1080", dsp.getString("udp_forward", "127.0.0.1:7300"), dsp.getBoolean("udp_forwarder_key", false), a.getBoolean("useTun2",true));
        } catch (Exception e)  {

        }
    }


    private void startVpnSocks(boolean dnsForward,final String socksServerAddress, final String udpForward, final boolean transparentDNS, final boolean use_Tun2Socks) {
        if (socksServerAddress == null) {
            throw new IllegalArgumentException("Must provide an IP address to a SOCKS server.");
        }
        if (tunFd == null) {
            throw new IllegalStateException("Must establish the VPN before connecting the tunnel.");
        }
        if (mTun2Socks != null) {
            throw new IllegalStateException("Tunnel already connected");
        }
        boolean useKeepAlive = sp.getBoolean("useKeepAlive",false);
        if (useKeepAlive) {
            addLog("KeepAlive is active");
            startKeepAlive();
        }
        String primaryDNS =  sp.getString("custom_primary_dns", "8.8.8.8");
        String secondaryDNS = sp.getString("custom_secondary_dns", "8.8.4.4");
        boolean custom_dns = dsp.getBoolean("enable_dns_key", false);
        if (custom_dns) {
            addLog(new StringBuffer().append("Custom DNS: ").append(primaryDNS).append(",").append(secondaryDNS).toString());
        } else {
            addLog("Using default DNS: 8.8.8.8,8.8.4.4");
        }
		
		String dnsgwRelay = null;
		
		try {
			mPrivateAddress = VPNUtils.selectPrivateAddress();;
			mRouter = mPrivateAddress.mRouter;
			
			} catch (Exception e) {}
		
        if (dnsForward) {
			
            int pdnsdPort = Utils.findAvailablePort(8091, 10);
			String dns1 =  sp.getString("custom_primary_dns", "8.8.8.8");
            String dns2 = sp.getString("custom_secondary_dns", "8.8.4.4");
			String[] dnsResolver = new String[]{dns1, dns2};
			dnsgwRelay = String.format("%s:%d", mPrivateAddress.mIpAddress, pdnsdPort);

			mPdnsd = new Pdnsd(this, dnsResolver, DNS_RESOLVER_PORT, mPrivateAddress.mIpAddress, pdnsdPort);
			mPdnsd.setOnPdnsdListener(new Pdnsd.OnPdnsdListener(){
					@Override
					public void onStart(){
						// mHostService.onDiagnosticMessage("pdnsd started");
					}
					@Override
					public void onStop(){
						// mHostService.onDiagnosticMessage("pdnsd stopped");
						// stop();
					}
				});
			mPdnsd.start();
			addLog("<b>DNS Forwarding Enabled</b>");
        }
        if(transparentDNS){
            addLog("<b>UDP Forwarding is active</b>");
        }
        addLog("<b><font color=#f12ADBE>Tunnel Connected </font></b>");   
        isRunning = true;

        boolean iswakeLock = sp.getBoolean("useWakeLock",false);
        if (iswakeLock) {
            PowerManager powerManager = (PowerManager)getApplicationContext().getSystemService(Context.POWER_SERVICE);
            wakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "MyWakelockTag");
            wakeLock.acquire();
        }      
		
        mTun2Socks = new Tun2Socks(this, tunFd, mMtu,
								   mRouter, VPN_INTERFACE_NETMASK, socksServerAddress,
								   udpForward, dnsgwRelay, transparentDNS);

		mTun2Socks.setOnTun2SocksListener(new Tun2Socks.OnTun2SocksListener(){
				@Override
				public void onStart()
				{
					// mHostService.onDiagnosticMessage("tun2socks started");
				}
				@Override
				public void onStop()
				{
					// mHostService.onDiagnosticMessage("tun2socks stopped")
				}
			});

		mTun2Socks.start();
    }

    public void onDisconnect()  {
        if (mThread != null)  {
            mThread.interrupt();
        }
        stopTunnelVPN();
    }

    private String readStream(InputStream in)   {
        StringBuilder sb = new StringBuilder();
        try {
            Reader reader = new BufferedReader(new InputStreamReader(in));
            char[] buff = new char[1024];
            while (true) {
                int read = reader.read(buff, 0, buff.length);
                if (read <= 0) {
                    break;
                }
                sb.append(buff, 0, read);
            }
        } catch (Exception e) {

        }
        return sb.toString();
    }

    public synchronized boolean establishVpnConntection()  {
        try {
            Locale.setDefault(Locale.ENGLISH);

            mPrivateAddress = VPNUtils.selectPrivateAddress();
            int prefixLength = mPrivateAddress.mPrefixLength;
            mRouter = mPrivateAddress.mRouter;

            c = new VpnService.Builder();
            c.setSession(getApplicationName());
            c.setConfigureIntent(SSHTunnelService.getGraphPendingIntent(getApplicationContext()));
            c.setMtu(mMtu);
            c.addAddress(mPrivateAddress.mIpAddress, prefixLength);
            mRoutes.addIP(new CIDRIP("0.0.0.0", 0), true);
            mRoutes.addIP(new CIDRIP("10.0.0.0", 8), false);
            mRoutes.addIP(new CIDRIP("192.168.0.0", 16), false);
            mRoutes.addIP(new CIDRIP("172.16.0.0", 12), false);
            mRoutes.addIP(new CIDRIP(InetAddress.getByName(new ConfigImpl().getHost()).getHostAddress(), 32), false);

            boolean enableTethering = sp.getBoolean("allow_tethering",false);
            if (enableTethering) {
                // USB tethering 192.168.42.x
                // Wi-Fi tethering 192.168.43.x
                mRoutes.addIP(new CIDRIP("192.168.42.0", 23), false);
                // Bluetooth tethering 192.168.44.x
                mRoutes.addIP(new CIDRIP("192.168.44.0", 24), false);
                // Wi-Fi direct 192.168.49.x
                mRoutes.addIP(new CIDRIP("192.168.49.0", 24), false);
            }

            boolean allowUnsetAF = Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP ;
            if (allowUnsetAF)  {
                allowAllAFFamilies(c);
            }

            String primaryDNS =  sp.getString("custom_primary_dns", "8.8.8.8");
            String secondaryDNS = sp.getString("custom_secondary_dns", "8.8.4.4");
            boolean dnsForward = dsp.getBoolean("dns_forwarder_key", false);              
            if (dnsForward) {
                try {
                    c.addDnsServer(primaryDNS);
                    c.addDnsServer(secondaryDNS);
                    mRoutes.addIP(new CIDRIP(primaryDNS, 32), true);
                    mRoutes.addIP(new CIDRIP(secondaryDNS, 32), true);                                 
                } catch (Exception e) {
                    addLog("Error Adding DNS Address " + e.getMessage());
                } 
            }

            Collection<NetworkSpace.IpAddress> positiveIPv4Routes = mRoutes.getPositiveIPList();
            NetworkSpace.IpAddress multicastRange = new NetworkSpace.IpAddress(new CIDRIP("224.0.0.0", 3), true);
            for (NetworkSpace.IpAddress route : positiveIPv4Routes)  {

                try {
                    if (!multicastRange.containsNet(route))  {
                        c.addRoute(route.getIPv4Address(), route.networkMask);                      
                    }
                }  catch (IllegalArgumentException ia) {
                    addLog("Route rejected by Android" + route + " " + ia.getLocalizedMessage());
                }
            }
            String excluded = TextUtils.join(", ", mRoutes.getNetworks(false)).replace(new ConfigImpl().getHost(), Utils.allStar(new ConfigImpl().getHost()));     
            addLog("Routes: " + TextUtils.join(", ", mRoutes.getNetworks(true)));
            addLog("Routes excluded: " + excluded);
            mRoutes.clear();
            tunFd = c.establish();
            addLog("Establishing a VPN Connection");
            return tunFd != null;
        }
        catch (Exception e) {
            addLog("Failed to establish a VPN " + e);
        }
        return false;
    }

    private void allowAllAFFamilies(VpnService.Builder builder) {
        builder.allowFamily(OsConstants.AF_INET);
        builder.allowFamily(OsConstants.AF_INET6);
    }

    public synchronized void stopTunnelVPN()  {
        
        if (mTun2Socks != null && mTun2Socks.isAlive()) {
			mTun2Socks.interrupt();
		}

		mTun2Socks = null;

		// teste
		//org.torproject.android.service.vpn.Tun2Socks.Stop();
		//ca.psiphon.PsiphonTunnel.Stop();

		if (mPdnsd != null && mPdnsd.isAlive()) {
			mPdnsd.interrupt();
		}

		mPdnsd = null;
        if (startKeepAlive != null)  {
            startKeepAlive.interrupt();
            startKeepAlive = null;
        }

        if (tunFd == null) {        
            return;
        }
        try    {
            tunFd.close();
        } catch (IOException e) {
            addLog("Closing VPN Interface error.");
        }
        finally  {
            tunFd = null;
        }
        isRunning = false;
        addLog("Closing VPN Interface.");
        addLog("<b><font color=\"red\">Tunnel Disconnected </font></b>");      
    }

    void addLog(String msg) {
        com.chadx.sockshttp.logger.Log.i("VPN_Service", msg);

    }

    public final String getApplicationName() throws PackageManager.NameNotFoundException    {
        PackageManager packageManager = getApplicationContext().getPackageManager();
        ApplicationInfo appInfo = packageManager.getApplicationInfo(getPackageName(), 0);
        return (String) packageManager.getApplicationLabel(appInfo);
    }
}
