package com.chadx.sockshttp;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.res.Configuration;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.PersistableBundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.chadx.sockshttp.preference.SettingsAdvancedPreference;



import com.chadx.sockshttp.view.RetrieveData;
import com.chadx.sockshttp.view.StoredData;
import com.chadx.ultrasshservice.util.securepreferences.SecurePreferences;


import com.google.android.material.tabs.TabLayout;
import com.google.android.material.textfield.TextInputEditText;

import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.DialogFragment;
import androidx.core.content.ContextCompat;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import androidx.core.view.GravityCompat;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.AppCompatRadioButton;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.appcompat.widget.SwitchCompat;
import androidx.appcompat.widget.Toolbar;
import android.text.Html;
import android.text.InputType;

import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.chadx.sockshttp.R;
import com.chadx.sockshttp.SocksHttpApp;
import com.chadx.sockshttp.activities.BaseActivity;
import com.chadx.sockshttp.activities.ConfigGeralActivity;
import com.chadx.sockshttp.adapter.LogsAdapter;
import com.chadx.sockshttp.adapter.SpinnerAdapter;
import com.chadx.sockshttp.util.AESCrypt;
import com.chadx.sockshttp.util.ConfigUpdate;
import com.chadx.sockshttp.util.ConfigUtil;
import com.chadx.sockshttp.util.Utils;
import com.chadx.ultrasshservice.LaunchVpn;
import com.chadx.ultrasshservice.SocksHttpService;
import com.chadx.ultrasshservice.StatisticGraphData;
import com.chadx.ultrasshservice.StatisticGraphData.DataTransferStats;
import com.chadx.ultrasshservice.config.ConfigParser;
import com.chadx.ultrasshservice.config.Settings;
import com.chadx.ultrasshservice.logger.ConnectionStatus;
import com.chadx.ultrasshservice.logger.SkStatus;
import com.chadx.ultrasshservice.tunnel.TunnelManagerHelper;
import com.chadx.ultrasshservice.tunnel.TunnelUtils;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;
import org.json.JSONException;
import org.json.JSONObject;
import com.chadx.sockshttp.adapter.PromoAdapter;
import android.content.ClipboardManager;
import android.content.ClipData;
import org.json.JSONArray;
import android.widget.CheckBox;
import android.util.TypedValue;
import android.preference.PreferenceManager;
import com.chadx.sockshttp.activities.InjectorService;
import com.google.android.material.snackbar.Snackbar;
import android.view.View.OnClickListener;
import com.chadx.sockshttp.activities.CustomDNS;

import android.graphics.Color;


import android.view.LayoutInflater;
import android.graphics.drawable.ColorDrawable;
import android.view.Gravity;
import android.widget.ImageView;
import java.security.GeneralSecurityException;
import java.util.concurrent.TimeUnit;

import android.content.pm.PackageManager;
import androidx.cardview.widget.CardView;
import com.chadx.sockshttp.model.StatusChangeListener;
import com.chadx.sockshttp.util.ConfigImpl;
import com.chadx.sockshttp.Service.SSHTunnelService;
import android.net.VpnService;
import android.text.method.HideReturnsTransformationMethod;
import android.text.TextWatcher;
import android.text.Editable;
import com.chadx.sockshttp.view.TunnelTypeActivity;
import com.chadx.sockshttp.view.SNISetupDialog;
import com.chadx.sockshttp.view.SquidSetupDialog;
import com.google.android.material.textfield.TextInputLayout;
import android.content.ServiceConnection;
import android.content.ComponentName;
import android.os.IBinder;
import com.chadx.sockshttp.Service.SSHTunnelService.LocalBinder;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.core.app.ActivityCompat;
import android.Manifest;
import com.chadx.sockshttp.logger.LogView;
import com.chadx.sockshttp.logger.Log;
import com.google.android.material.navigation.NavigationView;
import com.chadx.sockshttp.view.HTTPGenerator;
import com.chadx.sockshttp.view.SettingsActivity;
import com.chadx.sockshttp.view.SSHTunnelSettings;

/**
 * Activity Principal
 * @author SlipkHunter
 */

public class MainActivity extends BaseActivity
implements StatusChangeListener,  View.OnClickListener,SkStatus.StateListener, NavigationView.OnNavigationItemSelectedListener
{

	@Override
	public boolean onNavigationItemSelected(MenuItem p1) {
		switch (p1.getItemId()) {
			case R.id.payloadGenerator:
				startActivity(new Intent(MainActivity.this,HTTPGenerator.class));
				break;
			case R.id.meSettings:
				startActivity(new Intent(MainActivity.this, SettingsActivity.class));
				break;
			case R.id.sshSettings:
				startActivity(new Intent(getBaseContext(),SSHTunnelSettings.class));
				break;
			case R.id.aboutApp:
				
				break;
			case R.id.exit:
			//	showExit();
				break;
		}
		drawerLayout.closeDrawer(Gravity.START);
		return true;
	}
	

	@Override
	public void onLogReceived(String logString) {
	}


	@Override
    public void onStatusChanged(String status, Boolean isRunning) {
        if(isRunning) {
            start_vpn.setText("Stop"); 
			enabledWidget(false);
			if(SSHTunnelService.isSSHRunning) {
			}
		} else {
			start_vpn.setText("Start");
			enabledWidget(true);
		}
		onLogReceived(status);
    }
	
	private DrawerLayout drawerLayout;
    private ActionBarDrawerToggle actionBarDrawerToggle;
	private NavigationView navView;
	private Toolbar toolbar;
	
    private TextView connectionStatus;

    private LogsAdapter mLogAdapter;

    private RecyclerView logList;

	private Toolbar toolbar_main;

	private DrawerPanelMain mDrawerPanel;

	private TextView bytesIn;

	private TextView bytesOut;

	private CountDownTimer countDown;
//	private Button CircleImageView;
	private android.widget.ImageView ImageView;

	

	private static final String TAG = MainActivity.class.getSimpleName();
	private static final String UPDATE_VIEWS = "MainUpdate";
	public static final String OPEN_LOGS = "com.chadx.sockshttp:openLogs";
	private static ArrayList modeList = new ArrayList();
	
	
	private Settings mConfig;
//	private Toolbar toolbar_main;
	private Handler mHandler;
	
	private LinearLayout mainLayout;
	private LinearLayout loginLayout;
	private LinearLayout proxyInputLayout;
	private TextView proxyText;
	//private RadioGroup metodoConexaoRadio;
	private LinearLayout payloadLayout;
	private TextInputEditText payloadEdit;
	
	//private Button starterButton;
	
	private ImageButton inputPwShowPass;
	private TextInputEditText inputPwUser;
	private TextInputEditText inputPwPass;
	
	private LinearLayout configMsgLayout;
	private TextView configMsgText;
	
	private SharedPreferences prefs;

	private Switch imgFavorite;

	private ConfigUtil config;
	public static int PICK_FILE = 1;
	
	
	private LinearLayout messLay;

	private TextView tvMess;
	//private SpinnerAdapter serverAdapter;
	//private PromoAdapter payloadAdapter;
	//private ArrayList<JSONObject> serverList;
	//private ArrayList<JSONObject> payloadList;
	private CheckBox startSSHCheckbox;
	private CheckBox dnsCheckBox;
	private Handler fHandler = new Handler();
	private Thread dataUpdate;
	private Thread dataThread;
	public static String your_link  = "https://raw.githubusercontent.com/COD3CHADX/test/main/Update.json";
	public String versionName;
	public static TextView bytes_in_view;
	public static TextView bytes_out_view;
	private Context mContxt;
	private SharedPreferences myData;
	private boolean edit_state_pressed = false;
	private static final int S_ONSTART_CALLED = 2;
	private static final int S_BIND_CALLED = 1;
	private static SharedPreferences sp;
	
	private static final String[] tabTitle = {"HOME","LOGS"};
    private ViewPager vp;
    private TabLayout tabs;
	
	private Button start_vpn;
	private TextInputEditText etPayload;
	private CardView mTunTypeLayout;
	private LinearLayout mSquidLayout;
	
	private SharedPreferences.Editor editor;
	public static TextView tvSquid;
	public static TextView tvSNI;
	private CardView mPayloadLayout;
	private CardView mSSLLayout;
	private LinearLayout mMessageLayout;
	private TextView tvMessage;
	private TextView tvTunnelType;
	private static boolean isBound = false;
	private SSHTunnelService localService;
	

	@Override
    protected void onCreate(@Nullable Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
		mHandler = new Handler();
		mConfig = new Settings(this);
		//mDrawerPanel = new DrawerPanelMain(this);
		Thread.setDefaultUncaughtExceptionHandler(new ExceptionHandler(this));
		//SharedPreferences prefs = getSharedPreferences(SocksHttpApp.PREFS_GERAL, Context.MODE_PRIVATE);
		SSHTunnelService.addOnStatusChangedListener(this);
		new MyApplication().init(this);
		if (new MyApplication().isNightModeEnabled()) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
        } else {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
        }
        sp = MyApplication.getSharedPreferences();
        editor = MyApplication.getSharedPreferences().edit();
		int permissionCheck = ContextCompat.checkSelfPermission(this, android.Manifest.permission.WRITE_EXTERNAL_STORAGE);
        if (permissionCheck != PackageManager.PERMISSION_GRANTED)
        {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 101);
		}
		doLayout();
		toolbar=(Toolbar)findViewById(R.id.toolbar_main);
		setSupportActionBar(toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		IntentFilter filter = new IntentFilter();
		filter.addAction(UPDATE_VIEWS);
		filter.addAction(OPEN_LOGS);

		LocalBroadcastManager.getInstance(this)
			.registerReceiver(mActivityReceiver, filter);

	    mMessageLayout = (LinearLayout) findViewById(R.id.layoutMessage);
		mMessageLayout.setVisibility(View.GONE);
		tvMessage = (TextView) findViewById(R.id.tvMessage);
		mTunTypeLayout = (CardView) findViewById(R.id.layoutTunnelType);
		mTunTypeLayout.setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View p1) {
					startActivity(new Intent(MainActivity.this, TunnelTypeActivity.class));
				}
			});
		mSquidLayout = (LinearLayout) findViewById(R.id.layoutRemoteProxy);
		mSquidLayout.setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View p1) {
					new SquidSetupDialog(MainActivity.this);
				}
			});
		start_vpn = (Button) findViewById(R.id.activity_starterButtonMain);
        start_vpn.setOnClickListener(new OnClickListener(){

                @Override
                public void onClick(View p1) {
                    if (Utils.isNetworkOnline(MainActivity.this)) {
                        if (start_vpn.getText().toString().equals("Start")){                    
							start_vpn.setText("Stop");
							enabledWidget(false);
							Intent intent = VpnService.prepare(MainActivity.this);
							if (intent != null) {
								startActivityForResult(intent, 0);
							} else {
								onActivityResult(0, RESULT_OK, null);
							}           
                        } else {
                            start_vpn.setText("Start");
                            stopSSHClient();
							enabledWidget(true);
                        }
                    } else {
                        showToast("Please enable WiFi/Data before connect!");
                    }}});
		this.etPayload = (TextInputEditText) findViewById(R.id.etPayload);
        this.etPayload.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
        loadSavedPreferences();
        this.etPayload.addTextChangedListener(new TextWatcher() {
				public void onTextChanged(CharSequence s, int start, int before, int count) {
				}

				public void beforeTextChanged(CharSequence s, int start, int count, int after) {
				}

				public void afterTextChanged(Editable s) {
					editor.putString("netDataPreferences", etPayload.getText().toString()).commit();
				}
			});
		tvSquid = (TextView) findViewById(R.id.tvRemoteSquid);
		tvSNI = (TextView) findViewById(R.id.tvSni);
		tvTunnelType = (TextView) findViewById(R.id.tvTunnelType);
		mPayloadLayout = (CardView) findViewById(R.id.layoutPayload);
		mSSLLayout = (CardView) findViewById(R.id.layoutSNI);
		mSSLLayout.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View p1) {
					new SNISetupDialog(MainActivity.this).show();
				}
			});
    }
		

	void loadTun() {
		ConfigImpl mConfig = new ConfigImpl();
		if (!mConfig.isHaveConfig()) {
			if (mConfig.getConType() == R.id.rbDirect) {
				if (mConfig.isUsePayload()) {
					tvTunnelType.setText("Direct > SSH (Custom Payload)");
					mPayloadLayout.setVisibility(View.VISIBLE);
					mSSLLayout.setVisibility(View.GONE);
					mSquidLayout.setVisibility(View.GONE);
				} else {
					tvTunnelType.setText("Direct > SSH");
					mPayloadLayout.setVisibility(View.GONE);
					mSSLLayout.setVisibility(View.GONE);
					mSquidLayout.setVisibility(View.GONE);
				}
			} else if (mConfig.getConType() == R.id.rbProxy) {
				if (mConfig.isUsePayload()) {
					tvTunnelType.setText("HTTP Proxy > SSH (Custom Payload)");
					mPayloadLayout.setVisibility(View.VISIBLE);
					etPayload.setEnabled(true);
					mSSLLayout.setVisibility(View.GONE);
					mSquidLayout.setVisibility(View.VISIBLE);
				} else {
					tvTunnelType.setText("HTTP Proxy > SSH");
					mPayloadLayout.setVisibility(View.VISIBLE);
					etPayload.setEnabled(false);
					mSSLLayout.setVisibility(View.GONE);
					mSquidLayout.setVisibility(View.VISIBLE);
				}
			} else if (mConfig.getConType() == R.id.rbSSL) {
				tvTunnelType.setText("SSL/TLS > SSH");
				mPayloadLayout.setVisibility(View.GONE);
				mSSLLayout.setVisibility(View.VISIBLE);
				mSquidLayout.setVisibility(View.GONE);
			}
		} else {
			if (mConfig.getConType() == R.id.rbDirect) {
				if (mConfig.isUsePayload()) {
					tvTunnelType.setText("Direct > SSH (Custom Payload)");
				} else {
					tvTunnelType.setText("Direct > SSH");
				}
			} else if (mConfig.getConType() == R.id.rbProxy) {
				if (mConfig.isUsePayload()) {
					tvTunnelType.setText("HTTP Proxy > SSH (Custom Payload)");
				} else {
					tvTunnelType.setText("HTTP Proxy > SSH");
				}
			} else if (mConfig.getConType() == R.id.rbSSL) {
				tvTunnelType.setText("SSL/TLS > SSH");
			}
		}
	}


	
	private void enabledWidget(boolean z)
	{
		int con = new ConfigImpl().getConType();
		switch (con) {
			case R.id.rbDirect:
				etPayload.setEnabled(z);
				break;
			case R.id.rbProxy:
				etPayload.setEnabled(z);
				mSquidLayout.setEnabled(z);
				break;
			case R.id.rbSSL:
				mSSLLayout.setEnabled(z);
				break;
		}
		mTunTypeLayout.setEnabled(z);
	}


	private String render_bandwidth(double bw) {
		String postfix;
		float div;
		Object[] objArr;
		float bwf = (float) bw;
		if (bwf >= 1.0E12f) {
			postfix = "TB";
			div = 1.0995116E12f;
		} else if (bwf >= 1.0E9f) {
			postfix = "GB";
			div = 1.0737418E9f;
		} else if (bwf >= 1000000.0f) {
			postfix = "MB";
			div = 1048576.0f;
		} else if (bwf >= 1000.0f) {
			postfix = "KB";
			div = 1024.0f;
		} else {
			objArr = new Object[S_BIND_CALLED];
			objArr[0] = Float.valueOf(bwf);
			return String.format("%.0f", objArr);
		}
		objArr = new Object[S_ONSTART_CALLED];
		objArr[0] = Float.valueOf(bwf / div);
		objArr[S_BIND_CALLED] = postfix;
		return String.format("%.2f %s", objArr);
	}



	private void liveData()
	{
		dataUpdate = new Thread(new Runnable() {
			@Override
			public void run()
			{

				while (!dataUpdate.getName().equals("stopped"))
				{

					fHandler.post(new Runnable() {

						//private static final long xup = 0;

						@Override
						public void run()
						{
							if(toString().equals("Connected")){
								//graph.start();

							}
						}
					});

					try
					{
						Thread.sleep(1000);
					}
					catch (InterruptedException e)
					{
						e.printStackTrace();
					}
					//  progressStatus--;
				}

			}
		});

		dataUpdate.setName("started");
		dataUpdate.start();
	}








	final class MyThreadClass implements Runnable{
        @Override
        public void run(){
            int i = 0;
            synchronized (this)
			{
                while (dataThread.getName() == "showDataGraph")
				{
                    //  Log.e("insidebroadcast", Integer.toString(service_id) + " " + Integer.toString(i));

                    try
					{
                        wait(1000);
                        i++;
                    }
					catch (InterruptedException e)
					{
						// sshMsg(e.getMessage());
                    }

                }
				// stopSelf(service_id);
            }

        }
    }




	
	
	
	
	
	private void doLayout() {
	//	final SharedPreferences mPref = PreferenceManager.getDefaultSharedPreferences(this);
		setContentView(R.layout.activity_main_drawer);
		
	//	mChart = (LineChart) findViewById(R.id.chart1);
	//	graph = GraphHelper.getHelper().with(this).color(Color.parseColor(getString(R.color.colorPrimary))).chart(mChart);
    	
		liveData();
		drawerLayout = findViewById(R.id.drawerLayoutMain);
        actionBarDrawerToggle = new ActionBarDrawerToggle(this, drawerLayout, R.string.app_name, R.string.app_name);
        drawerLayout.addDrawerListener(actionBarDrawerToggle);
		navView = (NavigationView) findViewById(R.id.drawerNavigationView);
		navView.setNavigationItemSelectedListener(this);
        actionBarDrawerToggle.syncState();
		/*toolbar_main = (Toolbar) findViewById(R.id.toolbar_main);
		mDrawerPanel.setDrawer(toolbar_main);
		setSupportActionBar(toolbar_main);
	*/
		mainLayout = (LinearLayout) findViewById(R.id.activity_mainLinearLayout);
		loginLayout = (LinearLayout) findViewById(R.id.activity_mainInputPasswordLayout);
		//starterButton = (Button) findViewById(R.id.activity_starterButtonMain);
		inputPwUser = (TextInputEditText) findViewById(R.id.activity_mainInputPasswordUserEdit);
		inputPwPass = (TextInputEditText) findViewById(R.id.activity_mainInputPasswordPassEdit);
		inputPwShowPass = (ImageButton) findViewById(R.id.activity_mainInputShowPassImageButton);

		((TextView) findViewById(R.id.activity_mainAutorText))
			.setOnClickListener(this);

		proxyInputLayout = (LinearLayout) findViewById(R.id.activity_mainInputProxyLayout);
		proxyText = (TextView) findViewById(R.id.activity_mainProxyText);
      
     //   final SharedPreferences prefs = mConfig.getPrefsPrivate();
     //   SharedPreferences.Editor edit = prefs.edit();
		//SharedPreferences sPrefs = mConfig.getPrefsPrivate();
     //   sPrefs.edit().putBoolean(Settings.PROXY_USAR_DEFAULT_PAYLOAD, false).apply();
	//	sPrefs.edit().putInt(Settings.TUNNELTYPE_KEY, Settings.bTUNNEL_TYPE_SSH_PROXY).apply();
        config = new ConfigUtil(this);
		//serverSpinner = (Spinner) findViewById(R.id.serverSpinner);
	//	payloadSpinner = (Spinner) findViewById(R.id.payloadSpinner);
        connectionStatus = (TextView) findViewById(R.id.connection_status);
	//	serverList = new ArrayList<>();
	//	payloadList = new ArrayList<>();

	//	serverAdapter = new SpinnerAdapter(this, R.id.serverSpinner, serverList);
	//	payloadAdapter = new PromoAdapter(this, R.id.payloadSpinner, payloadList);

	//	serverSpinner.setAdapter(serverAdapter);
	//	payloadSpinner.setAdapter(payloadAdapter);

	//	loadServer();
	//	loadNetworks();
	//	updateConfig(true);

//AppVersion tknetwork
		PackageInfo pinfo = Utils.getAppInfo(this);
		if (pinfo != null) {
			String version_nome = pinfo.versionName;
			int version_code = pinfo.versionCode;
			String header_text = String.format("App Version: %s ", version_nome, version_code);

			TextView app_info_text = (TextView) findViewById(R.id.appversion);
			app_info_text.setText(header_text);
			config = new ConfigUtil(this);
			//ConfigVersion
			TextView version = (TextView)findViewById (R.id.configstats);
			version.setText("Config: "+config.getVersion());

		}


	//	this.mChart = (LineChart) findViewById(R.id.chart1);
	//	this.graph = GraphHelper.getHelper().with(this).color(Color.parseColor(getString(R.color.colorPrimary))).chart(mChart);

		
		//metodoConexaoRadio = (RadioGroup) findViewById(R.id.activity_mainMetodoConexaoRadio);
		
		start_vpn = (Button) findViewById(R.id.activity_starterButtonMain);
        start_vpn.setOnClickListener(new OnClickListener(){

                @Override
                public void onClick(View p1) {
                    if (Utils.isNetworkOnline(MainActivity.this)) {
                        if (start_vpn.getText().toString().equals("Start")){                    
							start_vpn.setText("Stop");
							enabledWidget(false);
							Intent intent = VpnService.prepare(MainActivity.this);
							if (intent != null) {
								startActivityForResult(intent, 0);
							} else {
								onActivityResult(0, RESULT_OK, null);
							}           
                        } else {
                            start_vpn.setText("Start");
                            stopSSHClient();
							enabledWidget(true);
                        }
                    } else {
                        showToast("Please enable WiFi/Data before connect!");
                    }}});
		
		
		//starterButton.setOnClickListener(this);
		proxyInputLayout.setOnClickListener(this);
		

		payloadLayout = (LinearLayout) findViewById(R.id.activity_mainInputPayloadLinearLayout);
		payloadEdit = (TextInputEditText) findViewById(R.id.activity_mainInputPayloadEditText);
		bytesIn = (TextView) findViewById(R.id.bytesIn);
        bytesOut = (TextView) findViewById(R.id.bytesOut);
		configMsgLayout = (LinearLayout) findViewById(R.id.activity_mainMensagemConfigLinearLayout);
		configMsgText = (TextView) findViewById(R.id.activity_mainMensagemConfigTextView);
	//	setSpinner();
		// fix bugs
		
        
        
		inputPwShowPass.setOnClickListener(this);
        
        doTabs();
	}
	
	private void updateHeaderCallback() {
		DataTransferStats dataTransferStats = StatisticGraphData.getStatisticData().getDataTransferStats();
		bytesIn.setText(dataTransferStats.byteCountToDisplaySize(dataTransferStats.getTotalBytesReceived(), false));
		bytesOut.setText(dataTransferStats.byteCountToDisplaySize(dataTransferStats.getTotalBytesSent(), false));
	}
    
    public void doTabs() {
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        vp = (ViewPager)findViewById(R.id.viewpager);
        tabs = (TabLayout)findViewById(R.id.tablayout);
        vp.setAdapter(new MyAdapter(Arrays.asList(tabTitle)));
        vp.setOffscreenPageLimit(2);
        tabs.setTabMode(TabLayout.MODE_FIXED);
        tabs.setTabGravity(TabLayout.GRAVITY_FILL);
        tabs.setupWithViewPager(vp);
	}
	
	public static void clear()
    {
        LogView.arrayList.clear();
        addLog(new StringBuffer().append("Running on ").append(Build.BRAND).append(" ").append(Build.MODEL).append(" (").append(Build.PRODUCT).append(") ").append(Build.MANUFACTURER).append(", Android API ").append(Build.VERSION.SDK).toString());
        addLog("Application version: " + "1.0.0 (Build 15) Unofficial Release");
		addLog("Log Cleared!");
    }

	public static void addLog(String str)
    {
        Log.i("EasySSH", str);
    }
	
	
	
	public class MyAdapter extends PagerAdapter
    {

        @Override
        public int getCount()
        {
            // TODO: Implement this method
            return 2;
        }

        @Override
        public boolean isViewFromObject(View p1, Object p2)
        {
            // TODO: Implement this method
            return p1 == p2;
        }

        @Override
        public Object instantiateItem(ViewGroup container, int position)
        {
            int[] ids = new int[]{R.id.tab1, R.id.tab2};
            int id = 0;
            id = ids[position];
            // TODO: Implement this method
            return findViewById(id);
        }

        @Override
        public CharSequence getPageTitle(int position)
        {
            // TODO: Implement this method
            return titles.get(position);
        }

        private List<String> titles;
        public MyAdapter(List<String> str)
        {
            titles = str;
        }
	}
		
	



	@Override
	public void onPostCreate(Bundle savedInstanceState, PersistableBundle persistentState) {
		super.onPostCreate(savedInstanceState, persistentState);
		if (mDrawerPanel.getToogle() != null)
			mDrawerPanel.getToogle().syncState();
	}

	@Override
	public void onConfigurationChanged(Configuration newConfig) {
		super.onConfigurationChanged(newConfig);
		if (mDrawerPanel.getToogle() != null)
			mDrawerPanel.getToogle().onConfigurationChanged(newConfig);
	}

	@Override
	public void onBackPressed() {

		if (drawerLayout.isDrawerOpen(Gravity.START)) {
			drawerLayout.closeDrawer(Gravity.START);
		} else {
			// mostra opção para sair
			LayoutInflater inflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			View inflate = inflater.inflate(R.layout.exit_dialog, (ViewGroup) null);
			AlertDialog.Builder builer = new AlertDialog.Builder(this);
			builer.setView(inflate);
			TextView title = inflate.findViewById(R.id.text_view_dialog1);
			TextView ms = inflate.findViewById(R.id.text_view_dialog2);
			Button ok = inflate.findViewById(R.id.text_view_exit_button);
			title.setText("Attention!");
			ms.setText("Are you sure you want to exit?");
			ok.setText("Exit");
			final AlertDialog alert = builer.create();
			alert.setCanceledOnTouchOutside(false);
			alert.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
			alert.getWindow().setGravity(Gravity.CENTER);
			alert.show();
			ok.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					try
					{
						alert.dismiss();
						Utils.exitAll(MainActivity.this);

					}
					catch (Exception e)
					{
						e.printStackTrace();
					}

				}});

			alert.show();
		}
	}
	
	
	
	void showToast(String s) {
		Toast.makeText(this, s,0).show();
	}

    

	
	
	
	

	/*private synchronized void doSaveData() {
        try {
            SharedPreferences prefs = mConfig.getPrefsPrivate();
            SharedPreferences.Editor edit = prefs.edit();
			if (!prefs.getBoolean(Settings.CONFIG_PROTEGER_KEY, false)) {
				if (!prefs.getBoolean(Settings.PROXY_USAR_DEFAULT_PAYLOAD, true)) {
					int pos = payloadSpinner.getSelectedItemPosition();
					// int modeType = prefs.getInt("TunnelMode",modeGroup.getCheckedRadioButtonId());


					boolean directModeType = config.getNetworksArray().getJSONObject(pos).getBoolean("isSSL");
					boolean sshssltype =  config.getNetworksArray().getJSONObject(pos).getBoolean("wsPayload");
					boolean remotessltype = config.getNetworksArray().getJSONObject(pos).getBoolean("remoteHost");
					boolean slowdnstype = config.getNetworksArray().getJSONObject(pos).getBoolean("SlowDns");
					if (directModeType) {
						prefs.edit().putInt(Settings.TUNNELTYPE_KEY, Settings.bTUNNEL_TYPE_SSH_SSL).apply();
						String sni = config.getNetworksArray().getJSONObject(pos).getString("SNI");
						edit.putString(Settings.CUSTOM_SNI, sni);
						edit.apply();

					} else if (sshssltype) {
						prefs.edit().putInt(Settings.TUNNELTYPE_KEY, Settings.bTUNNEL_TYPE_PAY_SSL).apply();
						String payload = config.getNetworksArray().getJSONObject(pos).getString("Payload");
						String snissl = config.getNetworksArray().getJSONObject(pos).getString("SNI");
						edit.putString(Settings.CUSTOM_PAYLOAD_KEY, payload);
						edit.putString(Settings.CUSTOM_SNI, snissl);
						edit.apply();
					}else if (remotessltype){
						prefs.edit().putInt(Settings.TUNNELTYPE_KEY, Settings.bTUNNEL_TYPE_SSL_RP).apply();
						String payloadrp = config.getNetworksArray().getJSONObject(pos).getString("Payload");
						String sslrp = config.getNetworksArray().getJSONObject(pos).getString("SNI");
						edit.putString(Settings.CUSTOM_PAYLOAD_KEY, payloadrp);
						edit.putString(Settings.CUSTOM_SNI, sslrp);
						edit.apply();
					}else if (slowdnstype){
						prefs.edit().putInt(Settings.TUNNELTYPE_KEY, Settings.bTUNNEL_TYPE_SLOWDNS).apply();
						String chvKey = config.getNetworksArray().getJSONObject(pos).getString("chaveKey");
						String nvKey = config.getNetworksArray().getJSONObject(pos).getString("serverNameKey");
						String dnsKey = config.getNetworksArray().getJSONObject(pos).getString("dnsKey");

						edit.putString(Settings.CHAVE_KEY, chvKey);
						edit.putString(Settings.NAMESERVER_KEY, nvKey);
						edit.putString(Settings.DNS_KEY, dnsKey);
						edit.apply();
					} else {
						prefs.edit().putInt(Settings.TUNNELTYPE_KEY, Settings.bTUNNEL_TYPE_SSH_PROXY).apply();
						String payload = config.getNetworksArray().getJSONObject(pos).getString("Payload");
						edit.putString(Settings.CUSTOM_PAYLOAD_KEY, payload);
						edit.apply();
					}
				}
			}
            
            edit.apply();
        } catch (Exception e) {
            e.printStackTrace();
        }
	}*/
	/*private void loadServerData() {
		try {
			SharedPreferences prefs = mConfig.getPrefsPrivate();
			SharedPreferences.Editor edit = prefs.edit();
			//    int modeType = prefs.getInt("TunnelMode",modeGroup.getCheckedRadioButtonId());
            int pos1 = serverSpinner.getSelectedItemPosition();
            int pos2 = payloadSpinner.getSelectedItemPosition();
            boolean directModeType = config.getNetworksArray().getJSONObject(pos2).getBoolean("isSSL");
            boolean sshssltype = config.getNetworksArray().getJSONObject(pos2).getBoolean("wsPayload");
			boolean remotessltype = config.getNetworksArray().getJSONObject(pos2).getBoolean("remoteHost");
			boolean slowdnstype = config.getNetworksArray().getJSONObject(pos2).getBoolean("SlowDns");
            if (directModeType) {
                String ssl_port = config.getServersArray().getJSONObject(pos1).getString("SSLPort");
                edit.putString(Settings.SERVIDOR_PORTA_KEY, ssl_port);

			} else if (sshssltype) {
				String ssl_port1 = config.getServersArray().getJSONObject(pos1).getString("SSLPort");
				edit.putString(Settings.SERVIDOR_PORTA_KEY, ssl_port1);

			} else if (remotessltype) {
				String ssl_port2 = config.getServersArray().getJSONObject(pos1).getString("SSLPort");
				edit.putString(Settings.SERVIDOR_PORTA_KEY, ssl_port2);

			} else if (slowdnstype) {
				edit.putString(Settings.SERVIDOR_KEY, "127.0.0.1");
				edit.putString(Settings.SERVIDOR_PORTA_KEY, "2222");
            } else {
                String ssh_port = config.getServersArray().getJSONObject(pos1).getString("ServerPort");
                edit.putString(Settings.SERVIDOR_PORTA_KEY, ssh_port);
            }
			String ssh_server = config.getServersArray().getJSONObject(pos1).getString("ServerIP");
			String remote_proxy = config.getServersArray().getJSONObject(pos1).getString("ProxyIP");
			String proxy_port = config.getServersArray().getJSONObject(pos1).getString("ProxyPort");
            String ssh_user = config.getServersArray().getJSONObject(pos1).getString("ServerUser");
            String ssh_password = config.getServersArray().getJSONObject(pos1).getString("ServerPass");
            edit.putString(Settings.USUARIO_KEY, ssh_user);
            edit.putString(Settings.SENHA_KEY, ssh_password);
			edit.putString(Settings.SERVIDOR_KEY, ssh_server);
			edit.putString(Settings.PROXY_IP_KEY, remote_proxy);
			edit.putString(Settings.PROXY_PORTA_KEY, proxy_port);
			edit.apply();


		} catch (Exception e) {
			e.printStackTrace();
		}
	}
*/
	/*private void loadServer() {
		try {
			if (serverList.size() > 0) {
				serverList.clear();
				serverAdapter.notifyDataSetChanged();
			}
			for (int i = 0; i < config.getServersArray().length(); i++) {
				JSONObject obj = config.getServersArray().getJSONObject(i);
				serverList.add(obj);
				serverAdapter.notifyDataSetChanged();

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void loadNetworks1() {
		try {
			if (payloadList.size() > 0) {
				payloadList.clear();
				payloadAdapter.clear();
			}
			JSONObject obj = getJSONConfig2(this);
			JSONArray networkPayload = obj.getJSONArray("Networks");
			for (int i = 0; i < networkPayload.length(); i++) {
				payloadList.add(networkPayload.getJSONObject(i));
			}
			//Collections.sort(listNetwork, NetworkNameComparator());
			payloadAdapter.notifyDataSetChanged();
		} catch (Exception e) {
			Toast.makeText(ChadXMainActivity.this, e.getMessage(), Toast.LENGTH_SHORT).show();
		}
	}

	private void loadNetworks() {
		try {
			if (payloadList.size() > 0) {
				payloadList.clear();
				payloadAdapter.notifyDataSetChanged();
			}
			for (int i = 0; i < config.getNetworksArray().length(); i++) {
				JSONObject obj = config.getNetworksArray().getJSONObject(i);
				payloadList.add(obj);
				payloadAdapter.notifyDataSetChanged();

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void updateConfig(final boolean isOnCreate) {
		new ConfigUpdate(this, new ConfigUpdate.OnUpdateListener() {
			@Override
			public void onUpdateListener(String result) {
				try {
					if (!result.contains("Error on getting data")) {
						String json_data = AESCrypt.decrypt(config.PASSWORD, result);
						if (isNewVersion(json_data)) {
							newUpdateDialog(result);
						} else {
							if (!isOnCreate) {
								noUpdateDialog();
							}
						}
					} else if(result.contains("Error on getting data") && !isOnCreate){
						errorUpdateDialog(result);
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}).start(isOnCreate);
	}
*/

	public static void updateSNI() {
		String sni;
		if (sp.getString("sniDataPreferences","").isEmpty()) {
			sni = "SNI (eg: www.pornhub.com)";
		} else {
			sni = sp.getString("sniDataPreferences","");
		}
		tvSNI.setText(sni);
	}
	
	public static void updateSquid() {
		String formatted;
		String host = sp.getString("proxyPreferences","");
		String port = sp.getString("portPreferences","");
		if (host.isEmpty() || port.isEmpty()) {
			formatted = "HTTP Proxy (eg: Squid)";
		} else {
			formatted =  String.format("%s:%s", host, port);
		}
		tvSquid.setText(formatted);
	}

	private void loadSavedPreferences() {
        etPayload.setText(sp.getString("netDataPreferences",""));
		if (Utils.isWorked()) {
			enabledWidget(false);
			start_vpn.setText("Stop");
		} else {
			start_vpn.setText("Start");
		}
    }
	
	
	private boolean isNewVersion(String result) {
		try {
			String current = config.getVersion();
			String update = new JSONObject(result).getString("Version");
			return config.versionCompare(update, current);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return false;
	}

	private void newUpdateDialog(final String result) throws JSONException, GeneralSecurityException{
        String json_data = AESCrypt.decrypt(config.PASSWORD, result);
        String notes = new JSONObject(json_data).getString("ReleaseNotes");
        LayoutInflater inflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View inflate = inflater.inflate(R.layout.new_update, (ViewGroup) null);
        AlertDialog.Builder builer = new AlertDialog.Builder(this); 
        builer.setView(inflate);
        ImageView iv = inflate.findViewById(R.id.new_Image);
        TextView title = inflate.findViewById(R.id.new_text1);
        TextView ms = inflate.findViewById(R.id.new_text2);
        Button ok = inflate.findViewById(R.id.new_button1);
        iv.setImageResource(R.drawable.icon);
        title.setText("New Update Available!");
        ms.setText(notes);
        ok.setText("UPDATE NOW");
        final AlertDialog alert = builer.create(); 
        alert.setCanceledOnTouchOutside(false);
        alert.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        alert.getWindow().setGravity(Gravity.CENTER); 
        alert.show();
        ok.setOnClickListener(new View.OnClickListener() { 
                @Override 
                public void onClick(View v) { 

                    // TODO: Implement this method
                    try
                    {
						alert.dismiss();
                        File file = new File(getFilesDir(), "Config.json");
                        OutputStream out = new FileOutputStream(file);
                        out.write(result.getBytes());
                        out.flush();
                        out.close();
                        restart_app();
                    }
                    catch (Exception e)
                    {
                        e.printStackTrace();
                    }

                }});

        alert.show();
    }

	private void noUpdateDialog() {
        LayoutInflater inflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View inflate = inflater.inflate(R.layout.update, (ViewGroup) null);
        AlertDialog.Builder builer = new AlertDialog.Builder(this); 
        builer.setView(inflate); 
        ImageView iv = inflate.findViewById(R.id.hadsImageView);
        TextView title = inflate.findViewById(R.id.hadsTextView1);
        TextView ms = inflate.findViewById(R.id.hadsTextView2);
        Button ok = inflate.findViewById(R.id.hadsButton);
        iv.setImageResource(R.drawable.icon);
        title.setText("What's New!");
        ms.setText("No new Update Available, Please try again soon.");
        ok.setText("HIDE");
        final AlertDialog alert = builer.create(); 
        alert.setCanceledOnTouchOutside(false);
        alert.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        alert.getWindow().setGravity(Gravity.CENTER); 
        alert.show();
        ok.setOnClickListener(new View.OnClickListener() { 
                @Override 
                public void onClick(View v) { 
                    try
                    {
						alert.dismiss();

                    }
                    catch (Exception e)
                    {
                        e.printStackTrace();
                    }

                }});

        alert.show();
    }

	private void errorUpdateDialog(String error) {

        LayoutInflater inflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View inflate = inflater.inflate(R.layout.error_update, (ViewGroup) null);
        AlertDialog.Builder builer = new AlertDialog.Builder(this); 
        builer.setView(inflate); 
        ImageView iv = inflate.findViewById(R.id.images_update_error1);
        TextView title = inflate.findViewById(R.id.text_view_update_error1);
        TextView ms = inflate.findViewById(R.id.text_view_update_error2);
        Button ok = inflate.findViewById(R.id.update_error);
        iv.setImageResource(R.drawable.icon);
        title.setText("Error on Update!");
        ms.setText("There is an error occurred while checking for update. Please contact Developer.");
        ok.setText("OKAY");
        final AlertDialog alert = builer.create(); 
        alert.setCanceledOnTouchOutside(false);
        alert.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        alert.getWindow().setGravity(Gravity.CENTER); 
        alert.show();
        ok.setOnClickListener(new View.OnClickListener() { 
                @Override 
                public void onClick(View v) { 
                    try
                    {
						alert.dismiss();

                    }
                    catch (Exception e)
                    {
                        e.printStackTrace();
                    }

                }});

        alert.show();
    }

	private void restart_app() {
		Intent intent = new Intent(this, MainActivity.class);
		int i = 123456;
		PendingIntent pendingIntent = PendingIntent.getActivity(this, i, intent, PendingIntent.FLAG_CANCEL_CURRENT);
		AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
		alarmManager.set(AlarmManager.RTC, System.currentTimeMillis() + ((long) 1000), pendingIntent);
		finish();
	}
	
	public void offlineUpdate() {
		Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
		intent.setType("*/*");
		startActivityForResult(intent, PICK_FILE);
	}
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);

		if (requestCode == PICK_FILE)
		{
			if (resultCode == RESULT_OK) {
				try {
					Uri uri = data.getData();
					String intentData = importer(uri);
					//String cipter = AESCrypt.decrypt(ConfigUtil.PASSWORD, intentData);
					File file = new File(getFilesDir(), "Config.json");
					OutputStream out = new FileOutputStream(file);
					out.write(intentData.getBytes());
					out.flush();
					out.close();
					//loadServer();
				//	loadNetworks();
					restart_app();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
	
	private String importer(Uri uri)
	{
		BufferedReader reader = null;
		StringBuilder builder = new StringBuilder();
		try
		{
			reader = new BufferedReader(new InputStreamReader(getContentResolver().openInputStream(uri)));

			String line = "";
			while ((line = reader.readLine()) != null)
			{
				builder.append(line);
			}
			reader.close();
		}
		catch (IOException e) {e.printStackTrace();}
		return builder.toString();
	} 
	/**
	 * Tunnel SSH
	 */

/*tknetwork 04/04/2022*/
	public void share(View v1){
		Intent sendIntent = new Intent();
		sendIntent.setAction(Intent.ACTION_SEND);
		sendIntent.putExtra(Intent.EXTRA_TEXT, "https://play.google.com/store/apps/details?id=com.voip.vpn");
		sendIntent.setType("text/plain");

		Intent shareIntent = Intent.createChooser(sendIntent, null);
		startActivity(shareIntent);

	}




	void isRunning(boolean z) {
		if (z) {
		//	payloadSpinner.setEnabled(false);
			//serverSpinner.setEnabled(false);


		} else {
			prefs.edit().putBoolean("isConnected", true).apply();
	//		payloadSpinner.setEnabled(true);
	//		serverSpinner.setEnabled(true);


		}
	}

	void stop(boolean c) {
		if (c) {
		//	payloadSpinner.setEnabled(true);
		//	serverSpinner.setEnabled(true);


		} else {
			prefs.edit().putBoolean("isDisconnect", true).apply();
		//	payloadSpinner.setEnabled(false);
	//		serverSpinner.setEnabled(false);


		}
	}


	public void startOrStopTunnel(Activity activity) {
		if (SkStatus.isTunnelActive()) {
            SharedPreferences prefs = mConfig.getPrefsPrivate();
			TunnelManagerHelper.stopSocksHttp(activity);
			this.startService(new Intent(this, InjectorService.class).setAction("STOP"));

		}
		else {
			// oculta teclado se vísivel, tá com bug, tela verde
			//Utils.hideKeyboard(activity);
			if(startSSHCheckbox.isChecked()){
				this.startService(new Intent(this, InjectorService.class).setAction("START"));
				//Toast.makeText(ChadXMainActivity.this, "Start SSH is running",
							  // Toast.LENGTH_SHORT).show();
			}else{
				this.startService(new Intent(this, InjectorService.class).setAction("STOP"));
				//Toast.makeText(ChadXMainActivity.this, "Start SSH is off",
							   //Toast.LENGTH_SHORT).show();
			}
			Settings mConfig = new Settings(activity);
			if (mConfig.getPrefsPrivate()
				.getBoolean(Settings.CONFIG_INPUT_PASSWORD_KEY, false)) {
				if (inputPwUser.getText().toString().isEmpty() || 
					inputPwPass.getText().toString().isEmpty()) {
					Toast.makeText(this, R.string.error_userpass_empty, Toast.LENGTH_SHORT)
						.show();
					return;
				}
			}
	
			
			Intent intent = new Intent(activity, LaunchVpn.class);
			intent.setAction(Intent.ACTION_MAIN);

			if (mConfig.getHideLog()) {
				intent.putExtra(LaunchVpn.EXTRA_HIDELOG, true);
			}

			activity.startActivity(intent);
		}
	}
	
	

	
	
	private boolean isMostrarSenha = false;
	
	@Override
	public void onClick(View p1)
	{
		SharedPreferences prefs = mConfig.getPrefsPrivate();

		switch (p1.getId()) {
			case R.id.activity_starterButtonMain:
		//		doSaveData();
		//		loadServerData();
				startOrStopTunnel(this);
				//isRunning(true);
				break;
			case R.id.activity_mainInputProxyLayout:
				break;
			case R.id.useDns:
				if(dnsCheckBox.isChecked()){
					Snackbar.make(p1, Html.fromHtml("<font color='#0A87FB'>Improved privacy and bypass Internet Censorship</font>"), Snackbar.LENGTH_LONG).setAction("SET DNS", new OnClickListener()
						{

							@Override
							public void onClick(View p1)
							{
								SharedPreferences mPref = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
								if(dnsCheckBox.getText().toString().equals("DNS (Default DNS)")){
									mPref.edit().putBoolean("Default_dns",true).apply();
									mPref.edit().putBoolean("Google_dns",false).apply();
									mPref.edit().putBoolean("Primary_dns",false).apply();
								}else if(dnsCheckBox.getText().toString().equals("DNS (Google DNS)")){
									mPref.edit().putBoolean("Default_dns",false).apply();
									mPref.edit().putBoolean("Google_dns",true).apply();
									mPref.edit().putBoolean("Primary_dns",false).apply();
									mPref.edit().putString(Settings.DNSRESOLVER_KEY1,"8.8.8.8").apply();
									mPref.edit().putString(Settings.DNSRESOLVER_KEY2,"8.8.4.4").apply();
								}else if(dnsCheckBox.getText().toString().equals("DNS (Primary DNS)")){
									mPref.edit().putBoolean("Default_dns",false).apply();
									mPref.edit().putBoolean("Google_dns",false).apply();
									mPref.edit().putBoolean("Primary_dns",true).apply();

								}else{
									mPref.edit().putBoolean(Settings.DNSFORWARD_KEY,false).apply();
									mPref.edit().putString(Settings.DNSTYPE_KEY, Settings.DNS_DEFAULT_KEY).apply();
									//custom.setText(mPref.getString(Settings.DNSTYPE_KEY,Settings.DNS_DEFAULT_KEY));
								}
								Intent TunnDNS = new Intent(MainActivity.this, CustomDNS.class);
								startActivity(TunnDNS);
							}


						}).show();
				} else {
					Toast.makeText(MainActivity.this, "DNS (Google DNS) is off",
								   Toast.LENGTH_SHORT).show();
				}
				break;

			case R.id.activity_mainAutorText:
				String url = "http://m.me/adik016";
				Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
				intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
				startActivity(Intent.createChooser(intent, getText(R.string.open_with)));
				break;
				
			case R.id.activity_mainInputShowPassImageButton:
				isMostrarSenha = !isMostrarSenha;
				if (isMostrarSenha) {
					inputPwPass.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
					inputPwShowPass.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.ic_visibility_black_24dp));
				}
				else {
					inputPwPass.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
					inputPwShowPass.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.ic_visibility_off_black_24dp));
				}
			break;
		}
	

	

	//	doSaveData();
		//doUpdateLayout();
	}

	public void logschadz(View v){

		startActivity(new Intent(MainActivity.this, SettingsAdvancedPreference.class));
	}
 
	protected void showBoasVindas() {
		new AlertDialog.Builder(this)
            . setTitle(R.string.attention)
            . setMessage(R.string.first_start_msg)
			. setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface di, int p) {
					// ok
				}
			})
			. setCancelable(false)
            . show();
	}


	
	@Override
    public void updateState(final String state, String msg, int localizedResId, final ConnectionStatus level, Intent intent)
    {
        mHandler.post(new Runnable() {
                @Override
                public void run() {
            //        doUpdateLayout();
                    if (SkStatus.isTunnelActive()){

                        if (level.equals(ConnectionStatus.LEVEL_CONNECTED)){
                            connectionStatus.setText(R.string.connected);
						//	progress.setProgressWithAnimation(100.0f);
							isRunning(true);
							//ads();

                        }

                        if (level.equals(ConnectionStatus.LEVEL_NOTCONNECTED)){
                            connectionStatus.setText(R.string.servicestop);
                        }   

                        if (level.equals(ConnectionStatus.LEVEL_CONNECTING_SERVER_REPLIED)){
                            connectionStatus.setText(R.string.authenticating);
						//	progress.setProgressWithAnimation(80.0f);
                        }       

                        if (level.equals(ConnectionStatus.LEVEL_CONNECTING_NO_SERVER_REPLY_YET)){
                            connectionStatus.setText(R.string.connecting);
						//	progress.setProgressWithAnimation(50.0f);
                        }           
                        if (level.equals(ConnectionStatus.LEVEL_AUTH_FAILED)){
                            connectionStatus.setText(R.string.authfailed);
						//	progress.setProgressWithAnimation(0.0f);
                        }                   
                        if (level.equals(ConnectionStatus.UNKNOWN_LEVEL)){
                            connectionStatus.setText(R.string.disconnected);
					//		progress.setProgressWithAnimation(0.0f);
							//ads();
                        }               
                        //if (level.equals(ConnectionStatus.LEVEL_RECONNECTING)){
                        //      status.setText(R.string.reconnecting);
                    }               
                    if (level.equals(ConnectionStatus.LEVEL_NONETWORK)){
                        connectionStatus.setText(R.string.nonetwork);
                    }           
                }
            });
		//show_progress(ev.progress, active);
		//show_stats();
		switch (state) {
			case SkStatus.SSH_CONECTADO:
				// carrega ads banner

			break;
		}
	}


	/**
	 * Recebe locais Broadcast
	 */

	private BroadcastReceiver mActivityReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (action == null)
                return;

            if (action.equals(UPDATE_VIEWS) && !isFinishing()) {
			//	doUpdateLayout();
			}
			
        }
    };


	@Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main_menu, menu);
		
        return true;
    }

	@Override
	public boolean onOptionsItemSelected(@NonNull MenuItem item) {
		if (actionBarDrawerToggle.onOptionsItemSelected(item)) {
			return true;
		}
		switch (item.getItemId()) {
			case R.id.menuSettings:
				startActivity(new Intent(MainActivity.this, SettingsActivity.class));
				break;
			
		}


		return super.onOptionsItemSelected(item);
	}


	
	
	
	void clearAppData() {
		AlertDialog.Builder ab = new AlertDialog.Builder(MainActivity.this);
		ab.setMessage("Are you sure you to reset all the data?");
		ab.setPositiveButton("YES", new DialogInterface.OnClickListener(){
				@Override
				public void onClick(DialogInterface p1, int p2)
				{
					ConfigImpl conf = new ConfigImpl();
					conf.setConType(R.id.rbProxy);
					conf.isUsePayload(true);
					conf.isHaveConfig(false);
					conf.setPayload("");
					conf.setSNI("");
					conf.setSquidHost("");
					conf.setSquidPort("");
					conf.setSSHHost("");
					conf.setSSHPort("22");
					conf.setSSHUser("");
					conf.setSSHPass("");
					onResume();
				}
			});
		ab.setNegativeButton("NO", null);
		ab.show();
	}
	
	private void updateapp()
    {
		try {
			versionName = getApplicationContext().getPackageManager().getPackageInfo(getApplicationContext().getPackageName(), 0).versionName;
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        new AppUpdateChecker(this, your_link, new AppUpdateChecker.Listener() {
                @Override
                public void onLoading(){}
                @Override
                public void onCompleted(final String config)
                {
                    try
                    {
                        final JSONObject obj = new JSONObject(config);
						if(versionName.equals(obj.getString("versionCode")))
						{
						//	Toast.makeText(ChadXMainActivity.this,("No Update Available") , Toast.LENGTH_LONG).show();
                        }else{
							//notif1();
							//	notif2();
							LayoutInflater inflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
							View inflate = inflater.inflate(R.layout.app_updater, (ViewGroup) null);
							AlertDialog.Builder builer = new AlertDialog.Builder(MainActivity.this); 
							builer.setView(inflate); 
							ImageView iv = inflate.findViewById(R.id.app_Image);
							TextView title = inflate.findViewById(R.id.app_text1);
							TextView ms = inflate.findViewById(R.id.app_text2);
							Button ok = inflate.findViewById(R.id.app_ok);
							iv.setImageResource(R.drawable.icon);
							title.setText("New Application!");
							ms.setText(obj.getString("Message"));
							ok.setText("Update Now");
							final AlertDialog alert = builer.create(); 
							alert.setCancelable(false);
							alert.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
							alert.getWindow().setGravity(Gravity.CENTER); 
							alert.show();
							ok.setOnClickListener(new View.OnClickListener() { 
									@Override 
									public void onClick(View v) { 
										try
										{
											alert.dismiss();
											startActivity(new Intent(Intent.ACTION_VIEW,
																	 Uri.parse(obj.getString("url"))));
										}
										catch (Exception e)
										{
											e.printStackTrace();
										}

									}});

							alert.show();
                        }
                    }
                    catch (Exception e)
                    {
                        // Toast.makeText(MainActivity.this, e.getMessage() , 0).show();
                    }

                }

                @Override
                public void onCancelled()
                {

                }

                @Override
                public void onException(String ex)
                {

                }
            }).execute();
    }

	/*private void setSpinner() {
		SecurePreferences prefsPrivate = mConfig.getPrefsPrivate();
		serverSpinner.setSelection(prefsPrivate.getInt("LastSelectedServer", 0));
		payloadSpinner.setSelection(prefsPrivate.getInt("LastSelectedPayload", 0));
	}

	private void saveSpinner() {
		edit = mConfig.getPrefsPrivate().edit();
		int selectedItemPosition = this.serverSpinner.getSelectedItemPosition();
		int selectedItemPosition2 = this.payloadSpinner.getSelectedItemPosition();
		putInt = edit.putInt("LastSelectedServer", selectedItemPosition);
		putInt = edit.putInt("LastSelectedPayload", selectedItemPosition2);
		edit.apply();
	}*/

	@Override
	public void onResume() {

		super.onResume();
		updateSNI();
		updateSquid();
		loadTun();
		loadSavedPreferences();
		loadConfig();
	}

	void loadConfig() {
		if(new ConfigImpl().isHaveConfig()) {
			((TextInputLayout)findViewById(R.id.tiPayloadLayout)).setVisibility(View.GONE);
			etPayload.setVisibility(View.GONE);
			mSquidLayout.setEnabled(false);
			tvSquid.setText("**********");
			mMessageLayout.setVisibility(View.VISIBLE);
			tvMessage.setText(new ConfigImpl().getConfigMessage());
		} else {
			((TextInputLayout)findViewById(R.id.tiPayloadLayout)).setVisibility(View.VISIBLE);
			etPayload.setVisibility(View.VISIBLE);
			mSquidLayout.setEnabled(true);
			mMessageLayout.setVisibility(View.GONE);
		}
	}

		

	private void checkNetwork() {
		ConnectivityManager connManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
		@SuppressLint("MissingPermission") NetworkInfo mWifi = connManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI);
		@SuppressLint("MissingPermission") NetworkInfo mMobile = connManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);

		if (mWifi.isConnected())
		{
			toolbar_main.setSubtitle("WI-FI: "+TunnelUtils.getLocalIpAddress());
			toolbar_main.setSubtitleTextAppearance(this, R.style.Toolbar_SubTitleText);

		} else if (mMobile.isConnected()) {

			toolbar_main.setSubtitle("MOBILE: "+TunnelUtils.getLocalIpAddress());
			toolbar_main.setSubtitleTextAppearance(this, R.style.Toolbar_SubTitleText);

		} else {
			toolbar_main.setSubtitle("NO CONNECTION");
			toolbar_main.setSubtitleTextAppearance(this, R.style.Toolbar_SubTitleText);
		}
	}




    @Override
    public void onStart() {
        bindService(new Intent(this, SSHTunnelService.class), connection, Context.BIND_AUTO_CREATE);
        super.onStart();
    }

	private ServiceConnection connection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName className, IBinder service) {
            LocalBinder binder = (LocalBinder) service;
            localService = binder.getService();
            isBound = true;
        }
        @Override
        public void onServiceDisconnected(ComponentName arg0) {
            isBound = false;
        }
    };

	private void stopSSHClient() {
		try {
			startService(new Intent(MainActivity.this, SSHTunnelService.class).setAction(SSHTunnelService.STOP_SSH));
		} catch (Exception e) {

		}
    }

    private void startSSHClient() {
		switch (new ConfigImpl().getTunnelType()) {
			case R.id.rbDirect:
				if(etPayload.getText().toString(). equals("")){
					Toast.makeText(getApplicationContext(), "Payload is Empty",Toast.LENGTH_LONG).show();
				} else if(new ConfigImpl().getHost().isEmpty()){
					showToast("Server address is Empty");
				} else if(new ConfigImpl().getPort().isEmpty()){
					showToast("Server port is Empty");                     
				} else if(new ConfigImpl().getUser().isEmpty() || new ConfigImpl().getPassword().isEmpty()) {
					showToast("SSH Authentication is Empty");
				}
				startVPN();
				break;
			case R.id.rbProxy:
				if(etPayload.getText().toString(). equals("")){
					Toast.makeText(getApplicationContext(), "Payload is Empty",Toast.LENGTH_LONG).show();
				} else if(new ConfigImpl().getHttpHost().isEmpty() || new ConfigImpl().getHttpPort().isEmpty()){
					showToast("Remote Proxy & Port is Empty");        
				} else if(new ConfigImpl().getUser().isEmpty() || new ConfigImpl().getPassword().isEmpty()) {
					showToast("SSH Authentication is Empty");
				}
				startVPN();
				break;
			case R.id.rbSSL:
				if (new ConfigImpl().getSNI().isEmpty()) {
					showToast("Server Name Indicator is Empty");
				} else if(new ConfigImpl().getUser().isEmpty() || new ConfigImpl().getPassword().isEmpty()) {
					showToast("SSH Authentication is Empty");
				}
				startVPN();
				break;

			default : startVPN();
		}
    }

	void startVPN() {
		try {         
			Intent intent = new Intent(MainActivity.this, SSHTunnelService.class);
			intent.setAction(SSHTunnelService.START_SSH);
			if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)	
				startForegroundService(intent);
			else
				startService(intent);
		} catch(Exception e){
		}
	}
	
	

	@Override
	protected void onPause()
	{
		super.onPause();
		
		//doSaveData();
		
		SkStatus.removeStateListener(this);

	}

	@Override
	protected void onDestroy()
	{
		super.onDestroy();

		LocalBroadcastManager.getInstance(this)
			.unregisterReceiver(mActivityReceiver);

	}


	/**
	 * DrawerLayout Listener
	 */

	/**
	 * Utils
	 */




	public static void updateMainViews(Context context) {
		Intent updateView = new Intent(UPDATE_VIEWS);
		LocalBroadcastManager.getInstance(context)
			.sendBroadcast(updateView);
	}
	
	public void showExitDialog() {
		AlertDialog dialog = new AlertDialog.Builder(this).
			create();
		dialog.setTitle(getString(R.string.attention));
		dialog.setMessage(getString(R.string.alert_exit));

		dialog.setButton(DialogInterface.BUTTON_POSITIVE, getString(R.
				string.exit),
			new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int which)
				{
					Utils.exitAll(MainActivity.this);
				}
			}
		);

		dialog.setButton(DialogInterface.BUTTON_NEGATIVE, getString(R.
				string.minimize),
			new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int which) {
					// minimiza app
					Intent startMain = new Intent(Intent.ACTION_MAIN);
					startMain.addCategory(Intent.CATEGORY_HOME);
					startMain.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
					startActivity(startMain);
				}
			}
		);

		dialog.show();
	}
}

