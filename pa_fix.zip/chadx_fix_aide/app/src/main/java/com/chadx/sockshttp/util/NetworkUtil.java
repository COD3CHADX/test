package com.chadx.sockshttp.util;

import android.app.ActivityManager;
import android.app.ActivityManager.RunningServiceInfo;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.NetworkInfo.State;
import android.os.Build;
import android.os.Build.VERSION;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.util.Log;
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.Objects;

public class NetworkUtil {
    private static final String CANDIDATE_10_SLASH_8 = "10.0.0.1";
    private static final String CANDIDATE_169_254_1_SLASH_24 = "169.254.1.1";
    private static final String CANDIDATE_172_16_SLASH_12 = "172.16.0.1";
    private static final String CANDIDATE_192_168_SLASH_16 = "192.168.0.1";
    private static final int PREFIX_LENGTH_10_SLASH_8 = 8;
    private static final int PREFIX_LENGTH_169_254_1_SLASH_24 = 24;
    private static final int PREFIX_LENGTH_172_16_SLASH_12 = 12;
    private static final int PREFIX_LENGTH_192_168_SLASH_16 = 16;
    private static final String ROUTER_10_SLASH_8 = "10.0.0.2";
    private static final String ROUTER_169_254_1_SLASH_24 = "169.254.1.2";
    private static final String ROUTER_172_16_SLASH_12 = "172.16.0.2";
    private static final String ROUTER_192_168_SLASH_16 = "192.168.0.2";
    private static final String SUBNET_10_SLASH_8 = "10.0.0.0";
    private static final String SUBNET_169_254_1_SLASH_24 = "169.254.1.0";
    private static final String SUBNET_172_16_SLASH_12 = "172.16.0.0";
    private static final String SUBNET_192_168_SLASH_16 = "192.168.0.0";
    private static final String TAG = "NetworkUtil";
    private static Enumeration<NetworkInterface> allNetInterfaces;

    public static String getIpAddress() {
        try {
            allNetInterfaces = NetworkInterface.getNetworkInterfaces();
            InetAddress inetAddress = (InetAddress) null;
            while (allNetInterfaces.hasMoreElements()) {
                Enumeration inetAddresses = ((NetworkInterface) allNetInterfaces.nextElement()).getInetAddresses();
                while (inetAddresses.hasMoreElements()) {
                    inetAddress = (InetAddress) inetAddresses.nextElement();
                    if (!(inetAddress == null || inetAddress.isLoopbackAddress() || !(inetAddress instanceof Inet4Address) || inetAddress.getHostAddress().toString().equals("10.0.2.15"))) {
                        if (VERSION.SDK_INT >= 23) {
                            return inetAddress.getHostAddress().toString();
                        }
                        if (!isTun(inetAddress.getHostAddress().toString()) && isStatusUP(inetAddress.getHostAddress().toString())) {
                            return inetAddress.getHostAddress().toString();
                        }
                    }
                }
            }
        } catch (Throwable e) {
            Log.e(TAG, e.getMessage(), e);
        }
        return "127.0.0.1";
    }

    private static boolean isTun(String str) {
        String runCommand = runCommand("netcfg");
        if (runCommand.equals("")) {
            return false;
        }
        String[] split = runCommand.split("\n");
        for (String split2 : split) {
            String[] split3 = split2.split(" ");
            String split22 = "";
            for (int i = 0; i < split3.length; i++) {
                if (!split3[i].equals("")) {
                    split22 = new StringBuffer().append(split22).append(new StringBuffer().append(split3[i]).append(" ").toString()).toString();
                }
            }
            String[] split4 = split22.split(" ");
            if (split4[2].trim().split("/")[0].equals(str) && split4[0].trim().startsWith("tun")) {
                return true;
            }
        }
        return false;
    }

    public static boolean vpnRunning() {
        String runCommand = runCommand("netcfg");
        if (runCommand.equals("")) {
            return false;
        }
        String[] split = runCommand.split("\n");
        for (String split2 : split) {
            String[] split3 = split2.split(" ");
            String split22 = "";
            for (int i = 0; i < split3.length; i++) {
                if (!split3[i].trim().equals("")) {
                    split22 = new StringBuffer().append(split22).append(new StringBuffer().append(split3[i]).append(" ").toString()).toString();
                }
            }
            if (split22.split(" ")[0].trim().startsWith("tun")) {
                return true;
            }
        }
        return false;
    }

    public static boolean isEmulator() {
        if (runCommand("netcfg").split("\n").length <= 4) {
            return true;
        }
        return false;
    }

    public static boolean isx86Port() {
        String property = System.getProperty("os.version");
        if (property == null || !property.contains("x86")) {
            return false;
        }
        return true;
    }

    public static String getNetworkTypeName(Context context) {
        ConnectivityManager connectivityManager =
            (ConnectivityManager)context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
        return networkInfo == null ? "" : networkInfo.getTypeName();
    }
    public static boolean isvm() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(new StringBuffer().append(new StringBuffer().append("Build.PRODUCT ").append(Build.PRODUCT).toString()).append("\n").toString());
        stringBuilder.append(new StringBuffer().append(new StringBuffer().append("Build.FINGERPRINT ").append(Build.FINGERPRINT).toString()).append("\n").toString());
        stringBuilder.append(new StringBuffer().append(new StringBuffer().append("Build.MANUFACTURER ").append(Build.MANUFACTURER).toString()).append("\n").toString());
        stringBuilder.append(new StringBuffer().append(new StringBuffer().append("Build.MODEL ").append(Build.MODEL).toString()).append("\n").toString());
        stringBuilder.append(new StringBuffer().append(new StringBuffer().append("Build.BRAND ").append(Build.BRAND).toString()).append("\n").toString());
        stringBuilder.append(new StringBuffer().append(new StringBuffer().append("Build.DEVICE ").append(Build.DEVICE).toString()).append("\n").toString());
        Log.i("LOB", stringBuilder.toString());
        Boolean bool = new Boolean(false);
        if ("google_sdk".equals(Build.PRODUCT) || "sdk_google_phone_x86".equals(Build.PRODUCT) || "sdk".equals(Build.PRODUCT) || "sdk_x86".equals(Build.PRODUCT) || "vbox86p".equals(Build.PRODUCT) || Build.FINGERPRINT.contains("generic") || Build.MANUFACTURER.contains("Genymotion") || Build.MODEL.contains("Emulator") || Build.MODEL.contains("Android SDK built for x86")) {
            bool = new Boolean(true);
        }
        if (Build.BRAND.contains("generic") && Build.DEVICE.contains("generic")) {
            bool = new Boolean(true);
        }
        return bool.booleanValue();
    }

    public static String getDeviceTun() {
        String str = "tun0";
        String runCommand = runCommand("netcfg");
        if (!runCommand.equals("")) {
            String[] split = runCommand.split("\n");
            for (String split2 : split) {
                String[] split3 = split2.split(" ");
                String split22 = "";
                for (int i = 0; i < split3.length; i++) {
                    if (!split3[i].trim().equals("")) {
                        split22 = new StringBuffer().append(split22).append(new StringBuffer().append(split3[i]).append(" ").toString()).toString();
                    }
                }
                String[] split4 = split22.split(" ");
                if (split4[0].trim().startsWith("tun")) {
                    return split4[0].trim();
                }
            }
        }
        return str;
    }

    public static String getDeviceTether() {
        String str = "wlan0";
        String runCommand = runCommand("netcfg");
        if (!runCommand.equals("")) {
            String[] split = runCommand.split("\n");
            for (String split2 : split) {
                String[] split3 = split2.split(" ");
                String str2 = "";
                for (int i = 0; i < split3.length; i++) {
                    if (!split3[i].equals("")) {
                        str2 = new StringBuffer().append(str2).append(new StringBuffer().append(split3[i]).append(" ").toString()).toString();
                    }
                }
                String[] split4 = str2.split(" ");
                if (split4[2].trim().split("/")[0].equals("192.168.43.1")) {
                    str = split4[0].trim();
                }
            }
        }
        return str;
    }

    private static boolean isStatusUP(String str) {
        String runCommand = runCommand("netcfg");
        if (runCommand.equals("")) {
            return false;
        }
        String[] split = runCommand.split("\n");
        for (String split2 : split) {
            String[] split3 = split2.split(" ");
            String split22 = "";
            for (int i = 0; i < split3.length; i++) {
                if (!split3[i].equals("")) {
                    split22 = new StringBuffer().append(split22).append(new StringBuffer().append(split3[i]).append(" ").toString()).toString();
                }
            }
            String[] split4 = split22.split(" ");
            if (split4[2].trim().split("/")[0].equals(str) && split4[1].trim().equalsIgnoreCase("UP")) {
                return true;
            }
        }
        return false;
    }

    public static String getDevice() {
        String str = "";
        String runCommand = runCommand("ip route");
        Log.d(TAG, new StringBuffer().append("output: ").append(runCommand).toString());
        String ipAddress = getIpAddress();
        Log.d(TAG, new StringBuffer().append("ip1: ").append(ipAddress).toString());
        String[] split = ipAddress.split("\\.");
        Log.d(TAG, new StringBuffer().append(new StringBuffer().append(new StringBuffer().append("ip2: ").append(split[0]).toString()).append(".").toString()).append(split[1]).toString());
        String[] split2 = runCommand.split("\n");
        for (int i = 0; i < split2.length; i++) {
            if (split2[i].startsWith(new StringBuffer().append(new StringBuffer().append(split[0]).append(".").toString()).append(split[1]).toString())) {
                runCommand = split2[i].split(" ")[2];
                Log.d(TAG, new StringBuffer().append("device: ").append(runCommand.trim()).toString());
                return runCommand;
            }
        }
        return str;
    }

    public static boolean isRoot() {
        try {
            Process exec = Runtime.getRuntime().exec("su");
            if (exec == null) {
                return false;
            }
            exec.destroy();
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public static String runCommand(String str) {
        StringBuilder stringBuilder = new StringBuilder();
        try {
            Process exec = Runtime.getRuntime().exec(str);
            exec.waitFor();
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(exec.getInputStream()));
            String str2 = "";
            while (true) {
                str2 = bufferedReader.readLine();
                if (str2 == null) {
                    break;
                }
                stringBuilder.append(new StringBuffer().append(str2).append("\n").toString());
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (InterruptedException e2) {
            e2.printStackTrace();
        }
        return stringBuilder.toString();
    }

    public static String runRootCommand(String str) throws IOException, Throwable {
        Process exec;
        DataOutputStream dataOutputStream;
        Exception e;
        Process process;
        Throwable th;
        Process process2 = (Process) null;
        DataOutputStream dataOutputStream2 = (DataOutputStream) null;
        StringBuilder stringBuilder = new StringBuilder();
        Log.d(TAG, str);
        try {
            exec = Runtime.getRuntime().exec("su");
            try {
                dataOutputStream = new DataOutputStream(exec.getOutputStream());
                try {
                    dataOutputStream.writeBytes(new StringBuffer().append(str).append("\n").toString());
                    dataOutputStream.writeBytes("exit\n");
                    dataOutputStream.flush();
                    exec.waitFor();
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(exec.getInputStream()));
                    String str2 = "";
                    while (true) {
                        str2 = bufferedReader.readLine();
                        if (str2 == null) {
                            break;
                        }
                        stringBuilder.append(new StringBuffer().append(str2).append("\n").toString());
                    }
                } catch (Exception e2) {
                    e = e2;
                    dataOutputStream2 = dataOutputStream;
                    process = exec;
                } catch (Throwable th2) {
                    th = th2;
                }
            } catch (Exception e3) {
                e = e3;
                process = exec;
                try {
                    Log.e(TAG, e.getMessage());
                    exec = process;
                    dataOutputStream = dataOutputStream2;
                    if (dataOutputStream != null) {
                        try {
                            dataOutputStream.close();
                        } catch (Exception e4) {
                        }
                    }
                    exec.destroy();
                    return stringBuilder.toString();
                } catch (Throwable th3) {
                    th = th3;
                    exec = process;
                    dataOutputStream = dataOutputStream2;
                    if (dataOutputStream != null) {
                        try {
                            dataOutputStream.close();
                        } catch (Exception e5) {
                            throw th;
                        }
                    }
                    exec.destroy();
                    throw th;
                }
            } catch (Throwable th4) {
                th = th4;
                dataOutputStream = dataOutputStream2;
                if (dataOutputStream != null) {
                    dataOutputStream.close();
                }
                exec.destroy();
                throw th;
            }
        } catch (Exception e6) {
            Exception exception = e6;
            process = process2;
            e = exception;
            Log.e(TAG, e.getMessage());
            exec = process;
            dataOutputStream = dataOutputStream2;
            if (dataOutputStream != null) {
                dataOutputStream.close();
            }
            exec.destroy();
            return stringBuilder.toString();
        } catch (Throwable th5) {
            exec = process2;
            th = th5;
            dataOutputStream = dataOutputStream2;
            if (dataOutputStream != null) {
                dataOutputStream.close();
            }
            exec.destroy();
            throw th;
        }
        if (dataOutputStream != null) {
            dataOutputStream.close();
        }
        exec.destroy();
        return stringBuilder.toString();
    }

    public static boolean connectionPresent(ConnectivityManager connectivityManager) {
        if (connectivityManager == null) {
            return false;
        }
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        if (activeNetworkInfo == null || activeNetworkInfo.getState() == null) {
            return false;
        }
        return activeNetworkInfo.getState().equals(State.CONNECTED);
    }

    public static boolean isStoreVersion(Context context) {
        try {
            if (TextUtils.isEmpty(context.getPackageManager().getInstallerPackageName(context.getPackageName()))) {
                return false;
            }
            return true;
        } catch (Throwable th) {
            return false;
        }
    }

    public static boolean isMyServiceRunning(Context context, Class<?> cls) {
        for (RunningServiceInfo runningServiceInfo : ((ActivityManager) context.getSystemService("activity")).getRunningServices(Integer.MAX_VALUE)) {
            if (cls.getName().equals(runningServiceInfo.service.getClassName())) {
                return true;
            }
        }
        return false;
    }

    public static String selectPrivateAddress() {
        ArrayList arrayList = new ArrayList();
        arrayList.add(CANDIDATE_10_SLASH_8);
        arrayList.add(CANDIDATE_172_16_SLASH_12);
        arrayList.add(CANDIDATE_192_168_SLASH_16);
        arrayList.add(CANDIDATE_169_254_1_SLASH_24);
        try {
            for (NetworkInterface inetAddresses : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                for (InetAddress inetAddress : Collections.list(inetAddresses.getInetAddresses())) {
                    String hostAddress = inetAddress.getHostAddress();
                    if (inetAddress instanceof Inet4Address) {
                        if (hostAddress.startsWith("10.")) {
                            arrayList.remove(CANDIDATE_10_SLASH_8);
                        } else if (hostAddress.length() >= 6 && hostAddress.substring(0, 6).compareTo("172.16") >= 0 && hostAddress.substring(0, 6).compareTo("172.31") <= 0) {
                            arrayList.remove(CANDIDATE_172_16_SLASH_12);
                        } else if (hostAddress.startsWith("192.168")) {
                            arrayList.remove(CANDIDATE_192_168_SLASH_16);
                        }
                    }
                }
            }
            if (arrayList.size() > 0) {
                return (String) arrayList.get(0);
            }
            return (String) null;
        } catch (SocketException e) {
            return (String) null;
        }
    }

    public static String getPrivateAddressSubnet(String str) {
        if (str.compareTo(CANDIDATE_10_SLASH_8) == 0) {
            return SUBNET_10_SLASH_8;
        }
        if (str.compareTo(CANDIDATE_172_16_SLASH_12) == 0) {
            return SUBNET_172_16_SLASH_12;
        }
        if (str.compareTo(CANDIDATE_192_168_SLASH_16) == 0) {
            return SUBNET_192_168_SLASH_16;
        }
        if (str.compareTo(CANDIDATE_169_254_1_SLASH_24) == 0) {
            return SUBNET_169_254_1_SLASH_24;
        }
        return (String) null;
    }

    public static int getPrivateAddressPrefixLength(String str) {
        if (str.compareTo(CANDIDATE_10_SLASH_8) == 0) {
            return PREFIX_LENGTH_10_SLASH_8;
        }
        if (str.compareTo(CANDIDATE_172_16_SLASH_12) == 0) {
            return PREFIX_LENGTH_172_16_SLASH_12;
        }
        if (str.compareTo(CANDIDATE_192_168_SLASH_16) == 0) {
            return PREFIX_LENGTH_192_168_SLASH_16;
        }
        if (str.compareTo(CANDIDATE_169_254_1_SLASH_24) == 0) {
            return PREFIX_LENGTH_169_254_1_SLASH_24;
        }
        return 0;
    }

    public static String getPrivateAddressRouter(String str) {
        if (str.compareTo(CANDIDATE_10_SLASH_8) == 0) {
            return ROUTER_10_SLASH_8;
        }
        if (str.compareTo(CANDIDATE_172_16_SLASH_12) == 0) {
            return ROUTER_172_16_SLASH_12;
        }
        if (str.compareTo(CANDIDATE_192_168_SLASH_16) == 0) {
            return ROUTER_192_168_SLASH_16;
        }
        if (str.compareTo(CANDIDATE_169_254_1_SLASH_24) == 0) {
            return ROUTER_169_254_1_SLASH_24;
        }
        return (String) null;
    }

    public static boolean isConnectedMobile(Context context) {
        NetworkInfo activeNetworkInfo = ((ConnectivityManager) context.getSystemService("connectivity")).getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected() && activeNetworkInfo.getType() == 0;
    }

    public static String getNetworkClass(Context context) {
        if (!isConnectedMobile(context)) {
            return "Data Off";
        }
        switch (((TelephonyManager) context.getSystemService("phone")).getNetworkType()) {
            case 1:
                return "GPRS";
            case 2:
                return "EDGE";
            case 3:
                return "UMTS";
            case 4:
                return "CDMA";
            case 5:
                return "EVDO";
            case 6:
                return "EVDO Rev. A";
            case 7:
                return "1xRTT";
            case PREFIX_LENGTH_10_SLASH_8 /*8*/:
                return "HSDPA";
            case 9:
                return "HSUPA";
            case 10:
                return "HSPA";
            case 11:
                return "iDen";
            case PREFIX_LENGTH_172_16_SLASH_12 /*12*/:
                return "EVDO Rev. B";
            case 13:
                return "LTE";
            case 14:
                return "eHRPD";
            case 15:
                return "HSPA+";    
			case 16:
				return "5G";
			default:
                return "Unknown";
        }
    }

    public static String isConnectionFast(Context context) {
        if (!isConnectedMobile(context)) {
            return "Not Available";
        }
        switch (((TelephonyManager) context.getSystemService("phone")).getNetworkType()) {
            case 0:
                return "Unknown";
            case 1:
                return "100 kbps";
            case 2:
                return "50-100 kbps";
            case 3:
                return "400-7000 kbps";
            case 4:
                return "14-64 kbps";
            case 5:
                return "400-1000 kbps";
            case 6:
                return "600-1400 kbps";
            case 7:
                return "50-100 kbps";
            case PREFIX_LENGTH_10_SLASH_8 /*8*/:
                return "2-14 Mbps";
            case 9:
                return "1-23 Mbps";
            case 10:
                return "700-1700 kbps";
            case 11:
                return "25 kbps";
            case PREFIX_LENGTH_172_16_SLASH_12 /*12*/:
                return "5 Mbps";
            case 13:
                return "10+ Mbps";
            case 14:
                return "1-2 Mbps";
            case 15:
                return "10-20 Mbps";
            default:
                return "Not Available";
        }
    }

    public String getNetworkStringClass(Context context) {
        String name = "";
        TelephonyManager mTelephonyManager = (TelephonyManager)
            context.getSystemService(Context.TELEPHONY_SERVICE);
        int networkType = Objects.requireNonNull(mTelephonyManager).getNetworkType();
        switch (networkType) {
            case TelephonyManager.NETWORK_TYPE_GPRS:
            case TelephonyManager.NETWORK_TYPE_EDGE:
            case TelephonyManager.NETWORK_TYPE_CDMA:
            case TelephonyManager.NETWORK_TYPE_1xRTT:
            case TelephonyManager.NETWORK_TYPE_IDEN: {
					name = "2G";
				}
                break;
            case TelephonyManager.NETWORK_TYPE_UMTS:
            case TelephonyManager.NETWORK_TYPE_EVDO_0:
            case TelephonyManager.NETWORK_TYPE_EVDO_A:
            case TelephonyManager.NETWORK_TYPE_HSDPA:
            case TelephonyManager.NETWORK_TYPE_HSUPA:
            case TelephonyManager.NETWORK_TYPE_HSPA:
            case TelephonyManager.NETWORK_TYPE_EVDO_B:
            case TelephonyManager.NETWORK_TYPE_EHRPD:
            case TelephonyManager.NETWORK_TYPE_HSPAP: {
					name = "3G";
				}
                break;
            case TelephonyManager.NETWORK_TYPE_LTE: {
					name = "LTE";
                }
                break;   
            default:
        }
        return null;
    }
}
