package com.chadx.sockshttp;

import com.chadx.sockshttp.R;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;


public class CrashWindow extends AppCompatActivity {

    private TextView error;
    @Override
    protected void onCreate(Bundle bundle) {
		super.onCreate(bundle);

		setContentView(R.layout.crash_window);
		this.error = (TextView) findViewById(R.id.crashwindow);
        this.error.setText(getIntent().getStringExtra("error"));
		Toolbar toolbar = (Toolbar) findViewById(R.id.tool_bar);
		setSupportActionBar(toolbar);
		toolbar.setTitleTextColor(Color.WHITE);
    }
}
