package com.chadx.sockshttp.view;

import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.preference.Preference;
import android.widget.LinearLayout;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.AppCompatEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.chadx.sockshttp.MyApplication;
import com.chadx.sockshttp.R;

public class BufferSizeDialog 
{

    private AlertDialog.Builder adb;

    private SharedPreferences sp;
    public BufferSizeDialog(Context c, final Preference p) {
        new MyApplication().init(c);
        sp = MyApplication.getSharedPreferences();
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -2);
        LinearLayout ll = new LinearLayout(c);
        ll.setOrientation(1);
        ll.setPadding(40,0,40,0);
        ll.setLayoutParams(layoutParams);
        final TextInputLayout til = new TextInputLayout(c);
        final AppCompatEditText acet = new AppCompatEditText(c);
        acet.setHint("Send");
        acet.setText(sp.getString("buffer_send", "1024"));
        til.addView(acet);
        final TextInputLayout til0 = new TextInputLayout(c);
        final AppCompatEditText acet0 = new AppCompatEditText(c);
        acet0.setHint("Receive");
        acet0.setText(sp.getString("buffer_receive", "4096"));
        til0.addView(acet0);
        ll.addView(til);
        ll.addView(til0);
        adb = new AlertDialog.Builder(c, R.style.Theme_MaterialComponents_Light_Dialog_Alert);
        adb.setCancelable(false);
        adb.setTitle("Buffer Size");
        adb.setMessage("Set the injection socket buffer size\n\n[WARNING] This is for advanced user only, do not edit this if you don't know what is your doing.");
        adb.setView(ll);
        adb.setPositiveButton("SAVE", new DialogInterface.OnClickListener(){
                @Override
                public void onClick(DialogInterface p1, int p2)
                {
                    // TODO: Implement this method
                    sp.edit().putString("buffer_send", acet.getText().toString()).commit();
                    sp.edit().putString("buffer_receive", acet0.getText().toString()).commit();
                    p.setSummary(new StringBuffer().append("Send: ").append(sp.getString("buffer_send", "1024")).append(" | Receive: ").append(sp.getString("buffer_receive", "4096")));
                }
            });
        adb.setNegativeButton("Cancel", null);
        adb.setNeutralButton("Reset", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface p1, int p2)
                {
                    // TODO: Implement this method
                    sp.edit().putString("buffer_send", "1024").commit();
                    sp.edit().putString("buffer_receive", "4096").commit();
                    p.setSummary(new StringBuffer().append("Send: ").append(sp.getString("buffer_send", "1024")).append(" | Receive: ").append(sp.getString("buffer_receive", "4096")));

                }
            });
    }

    public void show(){
        AlertDialog alert = adb.create();
        alert.getWindow().setBackgroundDrawableResource(R.drawable.popup_background);
		alert.show();
    }
}
