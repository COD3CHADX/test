package com.chadx.sockshttp;

import android.app.Activity;
import android.app.Application;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleObserver;
import androidx.lifecycle.OnLifecycleEvent;


import com.chadx.ultrasshservice.SocksHttpCore;

import android.content.Context;


import android.content.res.Configuration;
import android.content.SharedPreferences;
import android.os.Bundle;

import java.util.Date;

/**
* App
*/
public class SocksHttpApp extends Application implements Application.ActivityLifecycleCallbacks, LifecycleObserver {

    
    private Activity currentActivity;
    private static final String TAG = SocksHttpApp.class.getSimpleName();
    public static final String PREFS_GERAL = "SocksHttpGERAL";
    private static SharedPreferences sharedPreferences;
    //public static final String APP_FLURRY_KEY = "RQQ8J9Q2N4RH827G32X9";

    private static SocksHttpApp mApp;

    @Override
    public void onCreate()
    {
        super.onCreate();
        mApp = this;
        
        
        
        // inicia
        SocksHttpCore.init(this);

        // protege o app
       // SkProtect.init(this);
    }

    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(base);
        //LocaleHelper.setLocale(this);
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        //LocaleHelper.setLocale(this);
    }

   /* private void setModoNoturno(Context context) {
        boolean is = new Settings(context)
            .getModoNoturno().equals("on");

        int night_mode = is ? AppCompatDelegate.MODE_NIGHT_YES : AppCompatDelegate.MODE_NIGHT_NO;
        AppCompatDelegate.setDefaultNightMode(night_mode);
    }*/

    public static SocksHttpApp getApp() {
        return mApp;
    }
    public static SharedPreferences getSharedPreferences()  {
        return sharedPreferences;
    }
    public static SharedPreferences getDefSharedPreferences()  {
        return sharedPreferences;
    }



    @OnLifecycleEvent(Lifecycle.Event.ON_START)
    protected void onMoveToForeground() {
        // Show the ad (if available) when the app moves to foreground.
        
    }

    /** ActivityLifecycleCallback methods. */
    @Override
    public void onActivityCreated(@NonNull Activity activity, @Nullable Bundle savedInstanceState) {}

    @Override
    public void onActivityStarted(@NonNull Activity activity) {
        // An ad activity is started when an ad is showing, which could be AdActivity class from Google
        // SDK or another activity class implemented by a third party mediation partner. Updating the
        // currentActivity only when an ad is not showing will ensure it is not an ad activity, but the
        // one that shows the ad.
        
        
    }

    @Override
    public void onActivityResumed(@NonNull Activity activity) {}

    @Override
    public void onActivityPaused(@NonNull Activity activity) {}

    @Override
    public void onActivityStopped(@NonNull Activity activity) {}

    @Override
    public void onActivitySaveInstanceState(@NonNull Activity activity, @NonNull Bundle outState) {}

    @Override
    public void onActivityDestroyed(@NonNull Activity activity) {}

    

    /**
     * Interface definition for a callback to be invoked when an app open ad is complete
     * (i.e. dismissed or fails to show).
     */
    

/*tknetwork 04/04/2022*/
    
    
}
