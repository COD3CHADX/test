package com.chadx.sockshttp.model;

public interface config 
{
	public String getSNI();
	public String getPayload();
	public String getHttpHost();
	public String getHttpPort();
	public String getHost();
	public String getPort();
	public String getUser();
	public String getPassword();
	public boolean isAutoReconnect();
	public String getUa();
}
