package com.chadx.sockshttp.view;


import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.appcompat.widget.Toolbar;
import com.chadx.sockshttp.MyApplication;
import com.chadx.sockshttp.R;

public class HTTPGenerator extends AppCompatActivity
{
    private static ArrayAdapter<String> rAdapter, iAdapter, sAdapter;
    private static CheckBox cbBack;
    private static CheckBox cbDual;
    private static CheckBox cbForward;
    private static CheckBox cbFront;
    private static CheckBox cbKeep;
    private static CheckBox cbOnline;
    private static CheckBox cbRaw;
    private static CheckBox cbReferer;
    private static CheckBox cbReverse;
    private static CheckBox cbRotate;
    private static CheckBox cbUser;
    private static RadioGroup method;

    private static EditText payload;

    private static RadioButton rNomal,rSplit,rDirect;
    private static SharedPreferences prefs;
    private static SharedPreferences.Editor editor;
    private static Spinner injectSpin,requestSpin,splitSpin;
    private static String[] inject_items = new String[]{"Normal", "Front Inject", "Back Inject"};
    private static String[] request_items = new String[]{ "CONNECT", "GET", "POST", "PUT", "HEAD", "TRACE", "OPTIONS", "PATCH", "PROPATCH", "DELETE"};
    private static String[] split_items = new String[]{"Normal","Instant Split", "Delay Split"};
    private Toolbar toolbar;

    private static Button btn;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.generator);
        new MyApplication().init(this);
		if (new MyApplication().isNightModeEnabled()) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
        } else {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
        }
        prefs = MyApplication.getDefSharedPreferences();
        editor = prefs.edit();
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        toolbar.setTitle("Payload Generator");
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        payload = (EditText)findViewById(R.id.url_host);
        method = (RadioGroup)findViewById(R.id.method_group);
        method.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener(){
                @Override
                public void onCheckedChanged(RadioGroup p1, int p2)
                {
                    if (p2 == R.id.normal_mode) {
                        splitSpin.setEnabled(false);
                        injectSpin.setEnabled(true);
                        requestSpin.setSelection(0);
                        injectSpin.setSelection(0);                                                        
                    } else if (p2 == R.id.split_mode) {
                        injectSpin.setEnabled(true);
                        splitSpin.setEnabled(true);
                        requestSpin.setSelection(1);
                        injectSpin.setSelection(2);
                        splitSpin.setSelection(2);


                    } else if (p2 == R.id.direct_mode){
                        splitSpin.setEnabled(false);
                        injectSpin.setEnabled(false);
                    }
                }
            });                
        btn = (Button)findViewById(R.id.generate);
        btn.setOnClickListener(new View.OnClickListener(){

                @Override
                public void onClick(View p1)
                {
                    //editor.putString("xPayload",prefs.getString("Payload","")).commit();
                    String sPayload = payload.getText().toString();
                    StringBuilder sb = new StringBuilder();
                    String crlf = "[crlf]";
                    String space = " ";
                    String connect = "CONNECT ";
                    String host = "Host: ";
                    String host_port = "[host_port]";
                    String protocol = " [protocol]";
                    String outro = crlf + crlf;
                    String onePone = "HTTP/1.1";
                    String http = "http://";
                    String raw = "[raw]";
                    int r = requestSpin.getSelectedItemPosition();
                    int i = injectSpin.getSelectedItemPosition();
                    if(!rDirect.isChecked()){
                        switch(i){
                            case 0:
                                sb.append(connect);
                                if(cbFront.isChecked()){
                                    sb.append(sPayload).append("@");
                                    if(r == 0){
                                        sb.append(host_port);
                                        sb.append(protocol).append(crlf);
                                    }else{
                                        sb.append(host_port).append(space);
                                        sb.append(onePone);
                                        sb.append(outro);
                                        sb.append((String) requestSpin.getSelectedItem()).append(space);
                                        sb.append(http.concat(sPayload).concat("/"));
                                        sb.append(protocol).append(crlf);
                                    }
                                }else if(cbBack.isChecked()){
                                    sb.append(host_port).append("@").append(sPayload);
                                    if(r == 0){
                                        sb.append(protocol).append(crlf);
                                    }else{
                                        sb.append(space);
                                        sb.append(onePone);
                                        sb.append(outro);
                                        sb.append((String) requestSpin.getSelectedItem()).append(space);
                                        sb.append(http.concat(sPayload).concat("/"));
                                        sb.append(protocol).append(crlf);
                                    }
                                }else{
                                    if(r == 0){
                                        sb.append(host_port);
                                        sb.append(protocol).append(crlf);
                                        if(rSplit.isChecked()){
                                            int s = splitSpin.getSelectedItemPosition();
                                            switch(s){
                                                case 0:
                                                    sb.append("[split]");
                                                    sb.append(connect).append(http).append(sPayload).append("/").append(space).append(onePone).append(crlf);
                                                    break;
                                                case 1:
                                                    sb.append("[instant_split]");
                                                    sb.append(connect).append(http).append(sPayload).append("/").append(space).append(onePone).append(crlf);
                                                    break;
                                                case 2:
                                                    sb.append("[delay_split]");
                                                    sb.append(connect).append(http).append(sPayload).append("/").append(space).append(onePone).append(crlf);
                                                    break;
                                                default: break;
                                            }
                                        }
                                    }
                                }
                                break;
                            case 1:
                                sb.append((String) requestSpin.getSelectedItem()).append(space);
                                sb.append(http.concat(sPayload).concat("/")).append(space);
                                sb.append(onePone).append(crlf);
                                break;
                            case 2:
                                sb.append(connect);
                                if(cbFront.isChecked()){
                                    sb.append(sPayload).append("@");
                                    sb.append(host_port);
                                }else if(cbBack.isChecked()){
                                    sb.append(host_port);
                                    sb.append("@").append(sPayload);
                                }else{
                                    sb.append(host_port);
                                }
                                if(rSplit.isChecked()){
                                    sb.append(protocol);
                                    sb.append(crlf);
                                }else{
                                    sb.append(space);
                                    sb.append(onePone);
                                    sb.append(crlf);
                                }
                                if(rSplit.isChecked()){
                                    int s = splitSpin.getSelectedItemPosition();
                                    switch(s){
                                        case 0:
                                            sb.append("[split]");
                                            break;
                                        case 1:
                                            sb.append("[instant_split]");
                                            break;
                                        case 2:
                                            sb.append("[delay_split]");
                                            break;
                                        default: break;
                                    }
                                }else{
                                    sb.append(crlf);
                                }
                                sb.append((String) requestSpin.getSelectedItem()).append(space);
                                sb.append(http.concat(sPayload).concat("/"));
                                if(rSplit.isChecked()){
                                    sb.append(space).append(onePone).append(crlf);
                                }else{
                                    sb.append(protocol).append(crlf);
                                }
                                break;
                        }
                    }else{
                        String d = (String) requestSpin.getSelectedItem();
                        sb.append(d);
                        if(cbFront.isChecked())
                            sb.append(space).append(sPayload).append("@").append(host_port).append(protocol).append(crlf);
                        else if(cbBack.isChecked())
                            sb.append(" [host_port]").append("@").append(sPayload).append(protocol).append(crlf);
                        else
                            sb.append(space).append(host_port).append(protocol).append(crlf);
                    }
                    if(sPayload.isEmpty() || sPayload.equals("")){

                    }else{
                        sb.append(host).append(sPayload);

                        if(cbOnline.isChecked()){
                            sb.append(crlf).append("X-Online-Host: ").append(sPayload);
                        }
                        if(cbForward.isChecked()){
                            sb.append(crlf).append("X-Forward-Host: ").append(sPayload);
                        }
                        if(cbReverse.isChecked()){
                            sb.append(crlf).append("X-Forwarded-For: ").append(sPayload);
                        }
                    }
                    if(cbKeep.isChecked()){
                        sb.append(crlf).append("Connection: Keep-Alive");
                    }
                    if(cbUser.isChecked()){
                        sb.append(crlf).append("User-Agent: [ua]");
                    }
                    if(cbReferer.isChecked()){
                        sb.append(crlf).append("Referer: ").append(sPayload);
                    }
                    if(cbDual.isChecked()){
                        sb.append(crlf).append(connect).append(host_port).append(protocol);
                    }
                    if(i ==1){
                        sb.append(outro);
                        if(rSplit.isChecked()){
                            int s = splitSpin.getSelectedItemPosition();
                            switch(s){
                                case 0:
                                    sb.append("[split]");
                                    break;
                                case 1:
                                    sb.append("[instant_split]");
                                    break;
                                case 2:
                                    sb.append("[delay_split]");
                                    break;
                                default: break;
                            }
                        }
                        sb.append(connect);
                        if(cbFront.isChecked()){
                            sb.append(sPayload).append("@").append(host_port).append(protocol).append(outro);
                        }else if(cbBack.isChecked()){
                            sb.append(host_port).append("@").append(sPayload).append(protocol).append(outro);
                        }else{
                            sb.append(host_port).append(protocol).append(outro);
                        }
                    }else{
                        sb.append(outro);
                    }
                    String f = sb.toString();
                    if(cbRaw.isChecked()){
                        if(f.contains("CONNECT [host_port] [protocol]")){
                            String rw = f.replace("CONNECT [host_port] [protocol]",raw);
                            if(cbRotate.isChecked()){
                                if(!rw.toString().contains(";")){
                                    addLog("Invalid URL/Host");
                                }else{
                                    editor.putString("netDataPreferences",rw).apply();
                                }
                            }else{
                                editor.putString("netDataPreferences",rw).apply();
                            }
                        }
                    }else{
                        if(cbRotate.isChecked()){
                            if(!sb.toString().contains(";")){
                                addLog("Invalid URL/Host");
                            }else{
                                editor.putString("netDataPreferences",sb.toString()).apply();
                            }
                        }else{
                            editor.putString("netDataPreferences",sb.toString()).apply();
                        }

                    }

                    save();
                    finish();

                }

				private void addLog(String p0)
				{

				}               
            });
        rNomal = (RadioButton) findViewById(R.id.normal_mode);
        rSplit = (RadioButton) findViewById(R.id.split_mode);
        rDirect = (RadioButton) findViewById(R.id.direct_mode); 
        cbRotate = (CheckBox) findViewById(R.id.rotate);
        cbOnline = (CheckBox) findViewById(R.id.online_host);
        cbForward = (CheckBox) findViewById(R.id.forward_host);
        cbReverse = (CheckBox) findViewById(R.id.reverse_host);
        cbKeep = (CheckBox) findViewById(R.id.keep_alive);
        cbUser = (CheckBox) findViewById(R.id.user_agent);
        cbReferer = (CheckBox) findViewById(R.id.referer);
        cbFront = (CheckBox) findViewById(R.id.front_query);
        cbBack = (CheckBox) findViewById(R.id.back_query);
        cbRaw = (CheckBox) findViewById(R.id.raw);
        cbDual = (CheckBox) findViewById(R.id.dual_connect);
        requestSpin = (Spinner) findViewById(R.id.request_method);
        injectSpin = (Spinner) findViewById(R.id.inject_method);
        splitSpin = (Spinner) findViewById(R.id.split_method);          
        cbRotate.setOnCheckedChangeListener(cb);
        cbFront.setOnCheckedChangeListener(cb);
        cbBack.setOnCheckedChangeListener(cb);
        cbRaw.setOnCheckedChangeListener(cb);
        cbDual.setOnCheckedChangeListener(cb);          
        rAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, request_items);
        iAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, inject_items);
        sAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, split_items);
        requestSpin.setAdapter(rAdapter);
        injectSpin.setAdapter(iAdapter);
        splitSpin.setAdapter(sAdapter);
        rAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        iAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        requestSpin.setPrompt("Request Method");
        injectSpin.setPrompt("Injection Method");
        splitSpin.setPrompt("Split Method");
        requestSpin.setOnItemSelectedListener(isl);
        injectSpin.setOnItemSelectedListener(isl);
        load();
        splitSpin.setSelection(0);
        requestSpin.setSelection(0);
        injectSpin.setSelection(0);
        rNomal.setChecked(true);
    }






    private static AdapterView.OnItemSelectedListener isl = new AdapterView.OnItemSelectedListener(){
        @Override
        public void onItemSelected(AdapterView<?> p1, View p2, int p3, long p4)
        {
            int id = p1.getId();
            if(id == R.id.request_method){
                if(p3!=0){
                    if(injectSpin.getSelectedItemPosition() == 1){
                        return;
                    }else{
                        injectSpin.setSelection(2);
                    }
                }
                editor.putInt("reqSpin", p3).commit();
            }else if(id == R.id.inject_method){
                if(p3 !=0 ){
                    requestSpin.setSelection(1);
                }else if(p3 == 0){
                    if(rSplit.isChecked()){
                        rNomal.setChecked(true);
                    }
                    requestSpin.setSelection(0);
                }
                editor.putInt("injSpin", p3).commit();
            }
        }

        @Override
        public void onNothingSelected(AdapterView<?> p1)
        {
        }
    };
    private static void save(){
        editor.putString("payload_gen",payload.getText().toString()).commit();
        editor.putBoolean("normal", rNomal.isChecked()).commit();
        editor.putBoolean("split", rSplit.isChecked()).commit();
        editor.putBoolean("direct", rDirect.isChecked()).commit();
        editor.putBoolean("front_query", cbFront.isChecked()).commit();
        editor.putBoolean("back_query", cbBack.isChecked()).commit();
        editor.putBoolean("online_host", cbOnline.isChecked()).commit();
        editor.putBoolean("forward_host", cbForward.isChecked()).commit();
        editor.putBoolean("reverse_host", cbReverse.isChecked()).commit();
        editor.putBoolean("keep_alive", cbKeep.isChecked()).commit();
        editor.putBoolean("user_agent", cbUser.isChecked()).commit();
        editor.putBoolean("referer", cbReferer.isChecked()).commit();
        editor.putBoolean("raw", cbRaw.isChecked()).commit();
        editor.putBoolean("dual_connect", cbDual.isChecked()).commit();
        editor.putBoolean("rotate", cbRotate.isChecked()).commit();
    }
    private static void load(){
        cbRotate.setChecked(prefs.getBoolean("rotate",false));
        payload.setText(prefs.getString("payload_gen",""));
        rNomal.setChecked(prefs.getBoolean("normal", true));
        rSplit.setChecked(prefs.getBoolean("split", false));
        rDirect.setChecked(prefs.getBoolean("direct", false));
        cbBack.setChecked(prefs.getBoolean("back_query", false));
        cbFront.setChecked(prefs.getBoolean("front_query",false));
        cbOnline.setChecked(prefs.getBoolean("online_host", false));
        cbForward.setChecked(prefs.getBoolean("forward_host", false));
        cbReverse.setChecked(prefs.getBoolean("reverse_host", false));
        cbKeep.setChecked(prefs.getBoolean("keep_alive", false));
        cbUser.setChecked(prefs.getBoolean("user_agent", false));
        cbReferer.setChecked(prefs.getBoolean("referer", false));
        cbRaw.setChecked(prefs.getBoolean("raw", false));
        cbDual.setChecked(prefs.getBoolean("dual_connect", false));
        requestSpin.setSelection(prefs.getInt("reqSpin",0));
        injectSpin.setSelection(prefs.getInt("injSpin",0));
    }
    
    private static CompoundButton.OnCheckedChangeListener cb = new CompoundButton.OnCheckedChangeListener(){

        @Override
        public void onCheckedChanged(CompoundButton p1, boolean p2)
        {               
            switch (p1.getId()){                    
                case R.id.rotate:
                    if (cbRotate.isChecked()){                       
                     payload.setHint("URL/Host (eg: 1.com;2.com;3.com)");                         
                     } else {
                     payload.setHint(R.string.host);                  
                     }
                    break;
                case R.id.front_query:
                    if(p2){                         
                        cbBack.setChecked(false);                              
                    }
                    break;
                case R.id.back_query:
                    if(p2){                         
                        cbFront.setChecked(false);                              
                    }
                    break;
                case R.id.dual_connect:
                    if(p2){                         
                        cbRaw.setChecked(false);
                    }
                    break;
                case R.id.raw:
                    if(p2){                         
                        cbDual.setChecked(false);
                    }
                    break; 
            }
        }
    };     
}
