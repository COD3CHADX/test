package com.chadx.sockshttp;

import android.app.Application;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.preference.PreferenceManager;
import android.util.Log;
import android.webkit.WebView;
import android.widget.Toast;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import com.chadx.ultrasshservice.util.securepreferences.SecurePreferences;
import com.chadx.sockshttp.util.ConfigImpl;
import com.chadx.sockshttp.model.config;

public class MyApplication extends Application {

	private static Context context;
	private static SharedPreferences sharedPreferences;
	public static final String NIGHT_MODE = "NIGHT_MODE";
    private boolean isNightModeEnabled = false;
	public static volatile Context applicationContext = ((Context) null);
	private static ConfigImpl mConfig;

	public void init(Context c)
	{
		sharedPreferences = new SecurePreferences(c);
		sharedPreferences = PreferenceManager.getDefaultSharedPreferences(c);
		mConfig = new ConfigImpl();
		this.isNightModeEnabled = sharedPreferences.getBoolean(NIGHT_MODE, false);
	}

	public void onCreate() {
		MyApplication.context = getApplicationContext();
		try {
			ExtractPdnsd();
		} catch (IOException e){}
		applicationContext = getApplicationContext();
	}

	public boolean isNightModeEnabled() {
        return isNightModeEnabled;
    }

    public void setIsNightModeEnabled(boolean isNightModeEnabled) {
        this.isNightModeEnabled = isNightModeEnabled;

        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean(NIGHT_MODE, isNightModeEnabled);
        editor.apply();
    }

	public static SharedPreferences getSharedPreferences()
    {
        return sharedPreferences;
    }

	public static SharedPreferences getDefSharedPreferences()
    {
        return sharedPreferences;
    }


	public static Context getAppContext() {
		return context;
	}
	public static config getUtils(){
		return mConfig;
	}

	public void ExtractPdnsd() throws IOException
    {
        String pdnsd_binary = new StringBuilder().append(context.getFilesDir().getAbsolutePath()).append("/pdnsd").toString();
        InputStream inputStream = Build.VERSION.SDK_INT >= 21 ? context.getAssets().open("bin/pie/pdnsd") : context.getAssets().open("bin/pdnsd");
        if (inputStream == null)
        {
            return;
        }
        File pdnsd_file = new File(pdnsd_binary);
        if (!pdnsd_file.exists())
        {
            FileOutputStream fileOutputStream = new FileOutputStream(pdnsd_file);
            WriteTo(inputStream, fileOutputStream);
            pdnsd_file.setExecutable(true, true);
            pdnsd_file.setReadable(true, true);
            pdnsd_file.setWritable(true, true);
            fileOutputStream.close();
            inputStream.close();
            runCommand("chmod a+x " + context.getFilesDir().getAbsolutePath());
            runCommand("chmod a+x " + context.getFilesDir().getAbsolutePath() + "/pdnsd");

        }

	}

    public static void WriteTo(InputStream inputStream, FileOutputStream fileOutputStream) throws IOException  {
        byte[] arrby = new byte[2048];
        int n;
        while ((n = inputStream.read(arrby, 0, 2048)) != -1)
        {
            fileOutputStream.write(arrby, 0, n);
        }
        return;
    }

    public static boolean runCommand(String command)  {
        java.lang.Process process = null;
        DataOutputStream os = null;
		try {
			process = Runtime.getRuntime().exec("sh");
            try {

                os = new DataOutputStream(process.getOutputStream());
                os.writeBytes(command + "\n");
                os.writeBytes("exit\n");
                os.flush();
                process.waitFor();
                return true;
            }
            catch (Exception e)
            {

                Log.d("", e.getMessage());
                return false;

            }
            finally
            {
                try
                {
                    if (os != null)
                    {
                        os.close();
                    }
                    process.destroy();
                }
                catch (IOException e)
                {
                    // nothing
                }
            }
        }
        catch (IOException e)
        {
            Log.d("", e.getMessage());
            //SnapData.getSnapData().addLog(e.getMessage());
            return false;

        }
        finally
        {
            try
            {
                if (os != null)
                {
                    os.close();
                }
                process.destroy();
            }
            catch (Exception e)
            {
                // nothing
            }
        }

    }

}
