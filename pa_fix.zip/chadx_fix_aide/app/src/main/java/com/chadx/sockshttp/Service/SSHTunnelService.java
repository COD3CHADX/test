package com.chadx.sockshttp.Service;

import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.media.MediaPlayer;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Binder;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.Vibrator;
import android.util.Log;
import android.widget.Toast;
import androidx.annotation.RequiresApi;
import com.trilead.ssh2.Connection;
import com.trilead.ssh2.ConnectionMonitor;
import com.trilead.ssh2.DynamicPortForwarder;
import com.trilead.ssh2.HTTPProxyData;
import com.trilead.ssh2.InteractiveCallback;
import com.trilead.ssh2.KnownHosts;
import com.trilead.ssh2.ServerHostKeyVerifier;
import com.chadx.sockshttp.MainActivity;
import com.chadx.sockshttp.MyApplication;
import com.chadx.sockshttp.R;
import com.chadx.sockshttp.core.ProxyService;
import com.chadx.sockshttp.core.ProxyThread;
import com.chadx.sockshttp.core.SSLService;
import com.chadx.sockshttp.model.StatusChangeListener;
import com.chadx.sockshttp.Service.archivalservice.mLocalBinder;
import com.chadx.sockshttp.Service.SSHTunnelService;
import com.chadx.sockshttp.util.ConfigImpl;
import com.chadx.sockshttp.util.Constrains;
import com.chadx.sockshttp.util.NetworkUtil;
import com.chadx.sockshttp.util.Utils;
import com.chadx.sockshttp.view.LogFragment;
import java.io.IOException;
import java.lang.ref.WeakReference;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Locale;
import java.util.Map;
import java.util.Timer;
import java.util.concurrent.ConcurrentHashMap;

public class SSHTunnelService extends Service implements ServerHostKeyVerifier,
InteractiveCallback, ConnectionMonitor, Handler.Callback {

    public static final String NOTIFICATION_CHANNEL_ID = "sshtunnel";
    private static final int MSG_CONNECT_START = 0;
    private static final int MSG_CONNECT_FINISH = 1;
    private static final int MSG_CONNECT_SUCCESS = 2;
    private static final int MSG_CONNECT_FAIL = 3;
    private static final int MSG_DISCONNECT_FINISH = 4;
    public static final String START_SSH = "START";
    private static final String AUTH_PASSWORD = "password";
    private SharedPreferences settings = null;
    private DynamicPortForwarder dpf = null;
    public volatile static boolean isConnecting = false;
    public volatile static boolean isStopping = false;
	public volatile static boolean mReconnecting = false;
    public static final String STOP_SSH = "STOP";
	public static final String RECONNECT_SSH = "RECONNECT_SSH";
    public static final String SSL_PORT = "SSL_PORT";
    private final static int RECONNECT_TRIES = 5;
    private Connection connection;
    private Handler m_Handler = new Handler();
    private static ConcurrentHashMap<StatusChangeListener, Object> m_OnStatusChangedListeners=new ConcurrentHashMap<StatusChangeListener, Object>();
	private static final String TAG = "SSHTunnel";
    public static boolean isSSHThreadRunning = false;
    public static boolean isSSHRunning = false;
    private volatile boolean connected = false;
    public static boolean isAlive = false;
    private Thread sshThread;
	private String connectionType ="";
    private ServerSocket listen_proxy;
	private Socket client;
	private Socket server;
	private SharedPreferences sp;
    Thread startKeepAlive;
	private final IBinder binder = new LocalBinder();
    private boolean isBound = false;
    Notification.Builder builder =	null;
    archivalservice localService;
    private Timer updateTimer;
	private HTTPProxyData proxyData = null;;

    private ServiceConnection mConnection = new ServiceConnection() {  
        @Override
        public void onServiceConnected(ComponentName className, IBinder mService) {
            mLocalBinder mBinder = (mLocalBinder) mService;
            localService = mBinder.getService();
            isBound = true;
        }

        @Override
        public void onServiceDisconnected(ComponentName arg0) {
            isBound = false;
        }
    };

    public class LocalBinder extends Binder {

		public SSHTunnelService getService() {
			return SSHTunnelService.this;
		}

    }
	
	
    private static WeakReference<SSHTunnelService> sRunningInstance = null;

    public final static boolean isServiceStarted() {
        boolean isServiceStarted = false;
        if (sRunningInstance == null) {
            isServiceStarted = false;
        } else if (sRunningInstance.get() == null) {
            isServiceStarted = false;
            sRunningInstance = null;
        } else {
            isServiceStarted = true;
        }
        return isServiceStarted;
    }


	public boolean doVpnProtect(Socket socket) {
		if (new archivalservice().protect(socket)){
			addLog("Socket Protected");
			return true;
		}
		return false;
	}


    public static void addOnStatusChangedListener(StatusChangeListener listener)  {
        if (!m_OnStatusChangedListeners.containsKey(listener)) {
            m_OnStatusChangedListeners.put(listener, 1);
        }
    }

    public static void removeOnStatusChangedListener(StatusChangeListener listener)   {
        if (m_OnStatusChangedListeners.containsKey(listener)) {
            m_OnStatusChangedListeners.remove(listener);
        }
    }

    private void onStatusChanged(final String status, final boolean isRunning) {
        m_Handler.post(new Runnable() {
                @Override
                public void run() {
                    for (Map.Entry<StatusChangeListener, Object> entry : m_OnStatusChangedListeners.entrySet()) {
                        entry.getKey().onStatusChanged(status, isRunning);
                    }
                }
            });
    }

    public void writeLog(final String logs) {
        m_Handler.post(new Runnable() {
                @Override
                public void run() {
                    for (Map.Entry<StatusChangeListener, Object> entry : m_OnStatusChangedListeners.entrySet()) {
                        entry.getKey().onLogReceived(logs);
                    }
                }
            });
	}

	public static PendingIntent getGraphPendingIntent(Context context) {
		// Let the configure Button show the Log
		Intent intent = new Intent();
		intent.setComponent(new ComponentName(context,MainActivity.class));
		intent.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);

		PendingIntent startLW = PendingIntent.getActivity(context, 0, intent, 0);

		return startLW;
	}


    private void markServiceStarted() {
        sRunningInstance = new WeakReference<SSHTunnelService>(this);
    }

    private void markServiceStopped() {
        sRunningInstance = null;
    }

    // Flag indicating if this is an ARMv6 device (-1: unknown, 0: no, 1: yes)
    private String reason = null;
    private Handler handler;


	public void runProxyThread() {
		new Thread(new Runnable() {          
				public void run()	{
					try{
						listen_proxy = new ServerSocket(Integer.parseInt(sp.getString("local_port", "8989")));
						listen_proxy.setReuseAddress(true);
						addLog("Listening for incoming connection.");
                        addLog("Running - Proxy Thread");
                        addLog(new StringBuffer().append("Buffer Size: ").append("Send: ").append(sp.getString("buffer_send", "16384")).append(" | ").append("Receive: ").append(sp.getString("buffer_receive", "32768")).toString());                                                   
                        while (true) {
							client = listen_proxy.accept();
							addLog(new StringBuffer().append("Response from local port: " ).append(client.getPort()).toString());
							client.setSoTimeout(0);
							String sshHost = new ConfigImpl().getHost();
							String sshPort = new ConfigImpl().getPort();
							String remoteHost = new ConfigImpl().getHttpHost();
							String remotePort = new ConfigImpl().getHttpPort();
							String payload = new ConfigImpl().getPayload();
							String sni = new ConfigImpl().getSNI();
						    int TUNNEL_TYPE = new ConfigImpl().getConType();
							switch (TUNNEL_TYPE){
								case R.id.rbDirect:
								    server = new ProxyService(client,sshHost, sshPort, payload,SSHTunnelService.this).socket2();	
								    connectionType = "DIRECT > Payload";
									break;
								case R.id.rbSSL:
								    server = new SSLService(client,sshHost, sshPort, sni).socket();							
									connectionType = "SSL > TLS Tunnel";
									break;
                                case R.id.rbProxy:
							    	server = new ProxyService(client, remoteHost, remotePort, payload, SSHTunnelService.this).socket2();      	
							        connectionType = "HTTP > Payload";
									break;    
							} if (client != null) {
								client.setKeepAlive(true);
							} if (server != null) {
								server.setKeepAlive(true);
							} if (server == null)	{
						      	client.close();
							} else if (server.isConnected()){ 
								doVpnProtect(server);
								ProxyThread.connect(client, server);
							}
						}
					} catch (Exception e) {
					    reason = e.getMessage();
					}
				}
			}).start();		
	}


	public void stopProxyThread() {
		synchronized (this) {
			if (this.listen_proxy != null) {
				try{
					this.listen_proxy.close();
				}  catch (Exception e){
				}
			}
			if (this.client != null){
				try{
					this.client.close();
				} catch (IOException e2) {
				}
			} if (this.server != null) {
				try {
					this.server.close();
				} catch (Exception e3) {
				}
			}

		}
		addLog("Stopping - Proxy Thread");	
	}

	void addLog(String str) {
		handler.sendMessage(handler.obtainMessage(9, str));
		LogFragment.addLog(str);
	}

    public boolean connect() {	      
        boolean isUpstreamProxy = settings.getBoolean("isUpstreamProxy",false);
        String upstreamProxy = settings.getString("upstreamProxy", "");

        if (isUpstreamProxy) {
            try {
                if (upstreamProxy == null || upstreamProxy.equals(""))
                    throw new Exception();
                String[] proxyInfo = upstreamProxy.split("@");
                if (proxyInfo.length == 1) {
                    String[] hostInfo = proxyInfo[0].split(":");
                    if (hostInfo.length != 2)
                        throw new Exception();
                    proxyData = new HTTPProxyData(hostInfo[0],
                                                  Integer.valueOf(hostInfo[1]));
					//connection.setProxyData(proxyData);			
				} else if (proxyInfo.length == 2) {
                    String[] userInfo = proxyInfo[0].split(":");
                    if (userInfo.length != 2)
                        throw new Exception();
                    String[] hostInfo = proxyInfo[1].split(":");
                    if (hostInfo.length != 2)
                        throw new Exception();
					proxyData = new HTTPProxyData(hostInfo[0],
                                                  Integer.valueOf(hostInfo[1]), userInfo[0],
                                                  userInfo[1]);
					//connection.setProxyData(proxyData);						  
                } else {
                    throw new Exception();
                }
            } catch (Exception e) {
                if (reason == null)
                    reason = getString(R.string.upstream_format_error);
                return false;
            }
		} else {
            proxyData = new HTTPProxyData("127.0.0.1", Integer.parseInt(sp.getString(Constrains.LOCAL_PORT, "8989")));
        }
		try {
			String sshHost = new ConfigImpl().getHost();
			String sshPort = new ConfigImpl().getPort();
		    connection = new Connection(sshHost, Integer.parseInt(sshPort));

			if (proxyData != null)
				connection.setProxyData(proxyData);

			connection.addConnectionMonitor(this);
            boolean as = sp.getBoolean("data_compression_key",false);
            if (as) {
                connection.setCompression(true);
                addLog("<b>Data Compression Enable</b>");
            }
            boolean at = sp.getBoolean("tcp_forwarder_key", false);
            if (at) {
				connection.setTCPNoDelay(true);
            }
		    connection.connect(this, 10 * 1000, 20 * 1000);
            connected = true;

        } catch (Exception e) {
            addLog("SSH Error: " + e.getMessage());
            Log.e(TAG, "Problem in SSH connection thread during connecting", e);
            reason = e.toString();
            return false;
        }

        try {

            int tries = 0;
            while (connected && !connection.isAuthenticationComplete() && tries++ < 1) {     
                if (connection.isAuthMethodAvailable(new ConfigImpl().getUser(), AUTH_PASSWORD)) {
					addLog("Authenticating");
                    if (!new ConfigImpl().isHaveConfig()) {
						addLog(new StringBuffer().append("Username: ").append(new ConfigImpl().getUser()).toString());
					}
                    if (connection.authenticateWithPassword(new ConfigImpl().getUser(), new ConfigImpl().getPassword())) {
						addLog("Authenticating with password");
					} else {
						addLog("Authentication Failed. Check your username or password then try again.");
						addLog("Authentication Failed");
					}
				}           
                Thread.sleep(1000);
            }
        } catch (Exception e) {
            reason = e.toString();
            return false;
        }

        try {
            if (connection.isAuthenticationComplete()) {
				String int_port = settings.getString("dynamic_port","1080");
                try {
                    dpf = connection.createDynamicPortForwarder(Integer.parseInt(int_port));
                    addLog("Forward Successful");
                    return true;
                } catch (Exception e) {
                    addLog(e.getMessage());
                    Log.e(TAG, "Could not create local port forward", e);
                    return false;
                }

            } 
        } catch (Exception e) {
            reason = e.toString();
            return false;
        }

        return false;
    }

	@Override
	public void connectionLost(Throwable reason) {
		if (isConnecting || isStopping || mReconnecting) {
			return;
		}
        boolean ar = sp.getBoolean("auto_reconnect_key",false);
		if (reason != null) {
			if (reason.getMessage().contains("There was a problem during connect")) {
				if(ar && isSSHThreadRunning) {
					addLog("<strong>Connection Lost</strong>");            
					reconnectSSH();
				}
				return;
			} else if (reason.getMessage().contains(
						   "Closed due to user request")) {
				return;
			} else if (reason.getMessage().contains(
						   "The connect timeout expired")) {
				onDisconnect();
				return;
			} else if ( reason.getMessage().contains(
                           "Socket closed"))  {         
                return;
            }
		} else {
			onDisconnect();
			return;
		}

        if(ar && isSSHThreadRunning) {
            reconnectSSH();
        }
	}

	public void reconnectSSH() {
		if (isConnecting || isStopping || mReconnecting) {
			return;
		}

		mReconnecting = true;
		closeSSH();
		addLog("Reconnecting");

		try {
			Thread.sleep(1000);
		} catch(InterruptedException e) {
			mReconnecting = false;
			return;
		}

		for (int i = 0; i < RECONNECT_TRIES; i++) {
			if (isStopping) {
				mReconnecting = false;
				return;
			}

			int sleepTime = 5;
			if (!Utils.isNetworkOnline(this)) {
				addLog("No network available");
			}
			else {
				sleepTime = 3;
				isConnecting = true;
				addLog("<b>Reconnecting</b>");
				try {
					startSSHService();

					isConnecting = false;
					mReconnecting = false;
					//mConnected = true;

					return;
				} catch(Exception e) {
					addLog("<strong>" + getString(R.string.state_disconnected) + "</strong>");
				}

				isConnecting = false;
			}

			try {
				Thread.sleep(sleepTime*1000);
				i--;
			} catch(InterruptedException e2){
				mReconnecting = false;
				return;
			}
		}

		mReconnecting = false;

		onDisconnect();
	}

    @Override
    public IBinder onBind(Intent intent) {
        return binder;
    }


    @Override
    public void onCreate() {
        super.onCreate();
        Locale.setDefault(new Locale("en"));
        handler = new Handler(this);
        settings = MyApplication.getSharedPreferences();
		sp = MyApplication.getSharedPreferences();
    }

    /** Called when the activity is closed. */
    /*only SSH Closed when unexpectedly closing connection*/	
	public void closeSSH() {
		connected = false;
        new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        if (dpf != null) {
                            dpf.close();
                            dpf = null;
                        }
                    } catch (Exception ignore) {
                        // Nothing
                    }
                    if (connection != null) {
                        connection.close();
                        connection = null;
                    }
                    try {
                        if (sshThread != null) {
                            sshThread.interrupt();
                        }
                    } catch (Exception e) {

                    }
				}}).start();
		stopProxyThread();
		addLog("Disconnected");
		addLog("<strong>[STOP] Service Closed</strong>");   
	}

	/*Close all Thread*/
    public void onDisconnect() {
		connected = false;
        new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        if (dpf != null) {
                            dpf.close();
                            dpf = null;
                        }
                    } catch (Exception ignore) {
                        // Nothing
                    }
                    if (connection != null) {
                        connection.close();
                        connection = null;
                    }
                    try {
                        if (sshThread != null) {
                            sshThread.interrupt();
                        }
                    } catch (Exception e) {

                    }
				}}).start();
		status_handler.sendEmptyMessage(2);	
		markServiceStopped();
		stopProxyThread();
		isTunnel(false);
		isSSHRunning = false;
		addLog("Disconnected");
		addLog("<strong>[STOP] Service Closed</strong>");   
	}

	private void isTunnel(boolean startVpn) {
		if (startVpn) {
			Intent intent = new Intent(this, archivalservice.class);
		    startService(intent.setAction("START"));
            bindService(new Intent(this, archivalservice.class), mConnection, Context.BIND_AUTO_CREATE);

		} else {
			Intent intent = new Intent(this, archivalservice.class);
			startService(intent.setAction("STOP"));
            if (isBound) {
                unbindService(mConnection);
                isBound = false;
            }
		}	
	}

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent.getAction();
		if (action.equals(START_SSH)) {
		    Log.d(TAG, "Service Start");
			addLog("<strong>[START] Service Started</strong>");		
            addLog("Starting Injector Thread");		
            addLog(String.format("Current network: %s", NetworkUtil.getNetworkTypeName(getApplicationContext())));
			addLog("Network IP Address: " + NetworkUtil.getIpAddress());
            startSSHService();
            isSSHThreadRunning = true;
        } else if (action.equals(STOP_SSH)) {
            isSSHThreadRunning = false;
			stop_notification();
            onDisconnect();
        } else if (action.equals(RECONNECT_SSH)) {
            reconnectSSH();
			Toast.makeText(SSHTunnelService.this, "Force Reconnecting",Toast.LENGTH_LONG).show();
        } 
        return 1;

    }

	private void startSSHService() {
		boolean enableSSHThread = sp.getBoolean("enableSSHTunnel", true);
        if (enableSSHThread) {
			sshThread = new Thread(new Runnable() {
					@Override
					public void run() {
						handler.sendEmptyMessage(MSG_CONNECT_START);
						status_handler.sendEmptyMessage(0);
						if (connect()) {
							addLog("<strong>Connected</strong>");		
							handler.sendEmptyMessage(MSG_CONNECT_FINISH);
							handler.sendEmptyMessage(MSG_CONNECT_SUCCESS);
							status_handler.sendEmptyMessage(1);
						} else {
							handler.sendEmptyMessage(MSG_CONNECT_FINISH);
							handler.sendEmptyMessage(MSG_CONNECT_FAIL);
							try {
								Thread.sleep(1000);
							} catch (InterruptedException ignore) {
								// Nothing
							}
							connected = false;
							stopSelf();
						}
						isConnecting = false;
					}
				});    
			sshThread.start();
			runProxyThread();
			markServiceStarted();
        } else {
			runProxyThread();
			markServiceStarted();  
		}
	}


	@Override
	public void onDestroy() {
		super.onDestroy();
        stopSelf();        
	}

    // XXX: Is it right?
    @Override
    public String[] replyToChallenge(String name, String instruction,
                                     int numPrompts, String[] prompt, boolean[] echo) throws Exception {
        String[] responses = new String[numPrompts];
        for (int i = 0; i < numPrompts; i++) {
            // request response from user for each prompt
            if (prompt[i].toLowerCase().contains("password"))
                responses[i] = settings.getString("ssh_password", "");
        }
        return responses;
    }

    public boolean isOnline()   {
        ConnectivityManager manager = (ConnectivityManager) this.getSystemService(CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = manager.getActiveNetworkInfo();
        if (networkInfo == null) {
            if (reason == null)
                reason = "No Network Available";
            return false;
        }
        return true;
    }

	@Override
	public boolean verifyServerHostKey(String hostname, int port, String serverHostKeyAlgorithm, byte[] serverHostKey) throws Exception {
		try {
			String fingerPrint = KnownHosts.createHexFingerprint(serverHostKeyAlgorithm, serverHostKey); 
			addLog("Fingerprint: " + fingerPrint);
			return true;
		} catch (Exception e) {
			addLog("SSH: " + e.getMessage());
		}
		return false;

	}

    public class EventMsg   {
        public int state;
	}

    @SuppressLint({"HandlerLeak"})
    final Handler status_handler = new Handler() {
        public void handleMessage(Message msg) {
            if (sp == null) {
                sp = MyApplication.getSharedPreferences();     
            }
            switch (msg.what) {
					//CONNECTING
				case  0:
					onStatusChanged("CONNECTING", true);
					sp.edit().putBoolean("isThreadRunning", true).commit();
					showNotification(R.drawable.icon, "Connecting....", false);
					break;
					//CONNECTED
				case  1:
					onStatusChanged("DISCONNECT", true);
					sp.edit().putBoolean("isThreadRunning", true).commit();
					showNotification(R.drawable.icon, "Connected", true);
					break;
					//DISCONNECTED
				case  2:
					onStatusChanged("CONNECT", false); 
					sp.edit().putBoolean("isThreadRunning", false).commit();
					break;

            }
            super.handleMessage(msg);
        }
    };

    @Override
    public boolean handleMessage(Message msg) {
        Editor ed = settings.edit();
        switch (msg.what) {
            case MSG_CONNECT_START:
                ed.putBoolean("isConnecting", true);
                ed.putBoolean("isRunning", true);
                break;
            case MSG_CONNECT_FINISH:
                ed.putBoolean("isRunning", true);
                ed.putBoolean("isConnecting", false);
                ed.putBoolean("isSwitching", false);
                break;
            case MSG_CONNECT_SUCCESS:
                isSSHRunning = true;
                isTunnel(true);
                break;
            case MSG_CONNECT_FAIL:
                ed.putBoolean("isRunning", false);
                break;
            case MSG_DISCONNECT_FINISH:
                ed.putBoolean("isRunning", false);
                ed.putBoolean("isSwitching", false); 
                break;
        }
        ed.commit();
        return true;
    }

    public boolean isActive() {
        return this.isAlive;
    }

    private void showNotification(int ic, String str, boolean shwoSpeedometer) {
		NotificationManager nm = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
	    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
			createNotificationChannel(nm);
			builder = new Notification.Builder(this, NOTIFICATION_CHANNEL_ID);
		} else if (Build.VERSION.SDK_INT >= 28) {
			createNotificationChannel(nm);
			builder = new Notification.Builder(this, NOTIFICATION_CHANNEL_ID);
		} else {
			builder = new Notification.Builder(this);
		}
        builder.setSmallIcon(ic);
		builder.setContentTitle(getString(R.string.app_name));
		builder.setContentText(str);
        builder.setColor(getResources().getColor(R.color.colorPrimary)); //backward compatibility               
        builder.setOngoing(true);
        builder.setOnlyAlertOnce(true);                 
        builder.setPriority(NotificationManager.IMPORTANCE_MIN);
        builder.setCategory(Notification.CATEGORY_SERVICE);
		Notification notif = builder.getNotification();
		nm.notify(2, notif);
		startForeground(2, notif);    
        if (shwoSpeedometer) {
            addVpnActionsToNotification(builder);
            builder.setContentTitle(new StringBuffer().append("Tunnel Connected: ").append(connectionType).toString());
			//  showSpeedometer();
            vibrate();
		}
    }

	private void createNotificationChannel(NotificationManager nm) {
		NotificationChannel channel = new NotificationChannel(NOTIFICATION_CHANNEL_ID, "SSH Injector",NotificationManager.IMPORTANCE_DEFAULT);
		channel.setShowBadge(true);
		channel.setDescription("Notification showing if the Service is still running");
		nm.createNotificationChannel(channel);
	}

    private void vibrate()  {
        if (sp.getBoolean("vibrate", true)) {           
            long[] vb = {0, 100, 100, 100};
            Vibrator vb_service = (Vibrator)getSystemService(Context.VIBRATOR_SERVICE);
            vb_service.vibrate(vb, -1); 
        }
    }

	@RequiresApi(api = 20)
    private void addVpnActionsToNotification(Notification.Builder builder) {
        try {

			Intent broadcastIntent = new Intent(this, SSHTunnelService.class);
			broadcastIntent.setAction(SSHTunnelService.RECONNECT_SSH);
			PendingIntent pintent = PendingIntent.getService(this, 0, broadcastIntent, 0);
			try {
				Intent broadcastIntent2 = new Intent(this, SSHTunnelService.class);
				broadcastIntent2.setAction(SSHTunnelService.STOP_SSH);
				PendingIntent pintent2 = PendingIntent.getService(this, 0, broadcastIntent2, 0);
				/*	if (Build.VERSION.SDK_INT >= 23) {
				 builder.addAction(new Action.Builder(Icon.createWithResource(this, R.drawable.ic_autorenew_black_24dp), getString(R.string.reconnect), pintent).build());
				 builder.addAction(new Action.Builder(Icon.createWithResource(this, R.drawable.ic_both), getString(R.string.stop), pintent2).build());
				 return;
				 }

				 builder.addAction(new Action.Builder(R.drawable.ic_autorenew_black_24dp,"Force Reconnect", pintent).build());
				 builder.addAction(new Action.Builder(R.drawable.ic_both, "Stop", pintent2).build());*/
         	} catch (Throwable e) {
                throw new NoClassDefFoundError(e.getMessage());
            }
        } catch (Throwable e2) {
            throw new NoClassDefFoundError(e2.getMessage());
        }
    }

	private void stop_notification() {
        if (this.builder != null){
            builder = null;
            if (updateTimer != null){
                updateTimer.cancel();
                updateTimer = null;
            }         
            stopForeground(true);
        }
    }
}
