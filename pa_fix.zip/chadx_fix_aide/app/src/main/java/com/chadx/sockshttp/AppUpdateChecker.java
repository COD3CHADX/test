package com.chadx.sockshttp;

import android.content.*;
import android.os.*;
import android.util.*;
import java.io.*;
import java.net.*;

public class AppUpdateChecker extends AsyncTask<String, String, String> {
    private static final String TAG = "NetGuard.Download";
	private static final String PrivateKey = "Renz_FreeNet_PH";

    private Context context;
    private Listener listener;
	private String url;

	/** mga di ginagamit na variables
	 private PowerManager.WakeLock wakeLock;
	 private HttpURLConnection uRLConnection;
	 private InputStream is;
	 private BufferedReader buffer;
	 */

    public interface Listener {
        void onLoading();

        void onCompleted(String config) throws Exception;
        void onCancelled();
        void onException(String ex);
    }

    public AppUpdateChecker(Context context, String url, Listener listener) {
        this.context = context;
        this.url = url;
        this.listener = listener;
    }

    @Override
    protected void onPreExecute() {
        listener.onLoading();
    }

	// Start Fixed by Awoo
    @Override
    protected String doInBackground(String... urlArg) {
		StringBuilder sb = new StringBuilder();
		try {
			String api = url;
            if(!api.startsWith("http")) {
                api = new StringBuilder().append("http://").append(url).toString();
            }

			URL url = new URL(api);
			HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
			httpURLConnection.setRequestMethod("GET");
			httpURLConnection.setConnectTimeout(30000);
            httpURLConnection.setReadTimeout(30000);
			httpURLConnection.setDoInput(true);
			httpURLConnection.connect();

			InputStreamReader isr = new InputStreamReader(httpURLConnection.getInputStream());
			BufferedReader bufferedReader = new BufferedReader(isr);	
            while (true) {
				String readLine = bufferedReader.readLine();
				if (readLine == null) {
					break;
				}
				sb.append(readLine);
			}

			bufferedReader.close();
			httpURLConnection.disconnect();
			if (httpURLConnection != null) {
				try {
					httpURLConnection.disconnect();
				} catch (Exception e3) {
					e3.printStackTrace();
				}
			}
			return sb.toString();
		} catch (Exception e) {
			e.printStackTrace();
            return "Error on getting data: " + e.getMessage();
		}
	}
	// end of fixed line

    @Override
    protected void onCancelled() {
        super.onCancelled();
		// Log.i(TAG, "Cancelled");
		// pd.dismiss();
        listener.onCancelled();
    }

    @Override
    protected void onPostExecute(String result) {
        // wakeLock.release();
        // nm.cancel(1);
		// pd.dismiss();
		Log.i(TAG, PrivateKey);
		Log.i(TAG, "error while verifying the privateKey");
        try {
			if (result.equals("error")) {
				listener.onException(result);
			}
			else {
				listener.onCompleted(result);
			}
		}
		catch (Exception e){
			listener.onException(e.getMessage());
		}
    }
	/**
	 * Created by Renz Vincent C. Mortel on 11/11/20
	 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and
	 * associated documentation files (the "Software"), to deal in the Software without restriction,
	 * including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense,
	 * and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so,
	 * subject to the following conditions:
	 *
	 * The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
	 *
	 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
	 * NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
	 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
	 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH
	 * THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
	 */
}





