package com.chadx.sockshttp;

import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toolbar;
import android.os.CountDownTimer;
import android.app.Application;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class LauncherActivity extends AppCompatActivity
{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_splash_screen);

        new Handler().postDelayed(new Runnable() {
				@Override
				public void run() {
					Intent i = new Intent(LauncherActivity.this, MainActivity.class);
					startActivity(i);
					finish();
				}
			}, 5*1000);
    }

}

