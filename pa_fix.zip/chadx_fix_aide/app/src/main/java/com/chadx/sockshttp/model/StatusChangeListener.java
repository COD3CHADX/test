package com.chadx.sockshttp.model;

public interface StatusChangeListener {
    public void onStatusChanged(String status, Boolean isRunning);
    public void onLogReceived(String logString);
}
