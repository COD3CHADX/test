package com.chadx.sockshttp.view;

import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.view.LayoutInflater;
import android.view.View;
import androidx.appcompat.app.AlertDialog;
import com.chadx.sockshttp.MainActivity;
import com.chadx.sockshttp.MyApplication;
import com.chadx.sockshttp.R;
import com.google.android.material.textfield.TextInputEditText;


public class SNISetupDialog 
{
    private AlertDialog.Builder adb;
    private SharedPreferences sp;

    public SNISetupDialog(Context c) {
        new MyApplication().init(c);
        sp = MyApplication.getSharedPreferences();
        LayoutInflater i = LayoutInflater.from(c);
		View view = i.inflate(R.layout.dialog_sni,null);
		final TextInputEditText acet0 = (TextInputEditText) view.findViewById(R.id.etServerName);
        acet0.setText(sp.getString("sniDataPreferences", ""));
        adb = new AlertDialog.Builder(c, R.style.Theme_MaterialComponents_Light_Dialog_Alert);
        adb.setCancelable(false);
        adb.setTitle("Server Name Indication (SNI)");
        adb.setMessage("SNI (eg: example.com)");
        adb.setView(view);
        adb.setPositiveButton("SAVE", new DialogInterface.OnClickListener(){
                @Override
                public void onClick(DialogInterface p1, int p2)
                {
                    // TODO: Implement this
                    sp.edit().putString("sniDataPreferences", acet0.getText().toString()).commit();
					MainActivity.updateSNI();
					p1.dismiss();
                }
            });
        adb.setNegativeButton("Cancel", null);
        adb.setNeutralButton("Reset", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface p1, int p2)
                {
                    // TODO: Implement this method
                    sp.edit().putString("sniDataPreferences", "").clear().commit();
                    MainActivity.updateSNI();
					p1.dismiss();
                }
            });
    }

    public void show(){
        AlertDialog alert = adb.create();
        alert.getWindow().setBackgroundDrawableResource(R.drawable.popup_background);
		alert.show();
    }
}
